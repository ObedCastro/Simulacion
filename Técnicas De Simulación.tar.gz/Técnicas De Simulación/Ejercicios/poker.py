#!/usr/bin/pytho

def poker(valor):

valor= str(int(raw_input('ingrese numero:')))

repeat1= valor.count('0')

if  repeat1==4:

    print "poker"

if repeat1==3:

    print"Tercia"

    print repeat1

if  repeat1==2


