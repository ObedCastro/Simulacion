#! /user/bin/python

n= int(raw_input("Ingrese la cantidad de numeros aleatorios: "))
num1= int(raw_input("Ingrese el valor de la semilla 1: "))
num2= int(raw_input("Ingrese el valor de la semilla 2: "))

for i in range (n):
    cuadrados= str(num1*num2)
    num1=num2
    if (len(cuadrados)%2==1):
	    cuadrados="o"+cuadrados

    print "cuadrado:",cuadrados
	
    long1=len(cuadrados) -2
    long2=int(long1)//2
    
    
    num=int(cuadrados[long2: long2])
    print num
    print num/100.00

