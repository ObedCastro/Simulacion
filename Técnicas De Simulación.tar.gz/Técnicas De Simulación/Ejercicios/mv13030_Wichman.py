#!/usr/bin/python

lista=[]
top=int(raw_input("Cuantas veces desea generar numeros aleatorios: "))

for i in range(0,top):
	num1=int(raw_input("Valor de la semilla num1 de 1 a 30000: "))
	num2=int(raw_input("Valor de la semilla num2 de 1 a 30000: "))
	num3=int(raw_input("Valor de la semilla num3 de 1 a 30000: "))

	while ((num1 > 30000 or num1 < 1) or (num2 > 30000 or num2 < 1) or (num3 < 1 or num3 > 30000)):
		print "ERROR Numeros no estan en el rango 1 a 30000...Por favor ingrese numeros enteros de 1 a 30000.\n"
		
		num1=int(raw_input("Valor de la semilla num1 de 1 a 30000: "))
		num2=int(raw_input("Valor de la semilla num2 de 1 a 30000: "))
		num3=int(raw_input("Valor de la semilla num3 de 1 a 30000: "))
		
	num1=171 * (num1 % 177) - 2 * (num1/177)
	num1=172 * (num2 % 176) - 35 * (num2/176)
	num1=170 * (num3 % 178) - 63 * (num3/178)

	valor=(float(num1)/30269 + float(num2)/30307 + float(num3)/30323)%1
	print "\n", valor
	lista.append(valor)
		
print "\n", lista
