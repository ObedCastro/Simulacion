num=raw_input("Introdusca numero de 5 digitos: ")

if (len(num)!=5):
	print "Debe ser de 5 digitos."
else:
	for a in num:
		dig=a
		
		cant1=num.count(dig)
		
		if (cant1==5):
			print "pokarin de ", dig
			break
		if (cant1==4):
			print "pokar de ", dig
			break
		if (cant1==3):
			for j in num:
				if (j!=a):
					cant2=num.count(j)
					if (cant2==2):
						print "full de tres ", dig, "y dos " , j
						break
					else:
						print "Tercia de ", dig
						break
				else:
					continue
			break
		if (cant1==2):
			for j in num:
				if (j!=a):
					if (num.count(j)==3):
						print "full de dos ", dig, "y tres ", j
						break
					if (num.count(j)==2):
						print "dos pares de dos ", dig, " y dos ", j
						break
					else:
						print "par de dos ", dig
						break
			break
		if (num[0]!=num[1] and num[0]!=num[2] and num[0]!=num[3] and num[3]!=num[4]):
			print "Todos son diferentes"
			break
