#!/usr/bin/python

lista=[]
top=int(raw_input("introdusca la cantidad de numeros aleatorios a operar: "))

for i in range(0,top):
	s1=int(raw_input("introdusca semilla s1 de 0 a 30000: "))
	s2=int(raw_input("Intrudusca semilla s2 de 0 a 30000: "))
	s3=int(raw_input("Intrudusca semilla s3 de 0 a 30000: "))

	while ((s1 > 30000 or s1 < 1) or (s2 > 30000 or s2 < 1) or (s3 < 1 or s3 > 30000)):
		print "Escriban enteros de 0 a 30000.\n"
		
		s1=int(raw_input("introdusca semilla s1 de 0 a 30000: "))
		s2=int(raw_input("Intrudusca semilla s2 de 0 a 30000: "))
		s3=int(raw_input("Intrudusca semilla s3 de 0 a 30000: "))
		
	s1=171 * (s1 % 177) - 2 * (s1/177)
	s2=172 * (s2 % 176) - 35 * (s2/176)
	s3=170 * (s3 % 178) - 63 * (s3/178)

	r=(float(s1)/30269 + float(s2)/30307 + float(s3)/30323)%1
	print "\n", r
	lista.append(r)
		
print "\n", lista
