#!/usr/bin/python

pedirnum=0
numaletoriedad=0

pedirnum=int(raw_input('Ingrese un numero mayor a 1000:'))
numaleatoriedad=int(raw_input('Ingrese un numero para aletoriedad:'))

print(numaleatoriedad)

for i in range(0,numaleatoriedad):
	numeroguardado=pedirnum**2
	numcadena=str(numeroguardado)
	tamanum=len(numcadena)
	ciclo = int(tamanum)-8
	ciclo = ciclo*-1
	for b in range(0,ciclo):
		numcadena="0"+numcadena
	
	nuevonum=numcadena[2:6]
	print nuevonum
	numaleatoriedad=int(nuevonum)

	


