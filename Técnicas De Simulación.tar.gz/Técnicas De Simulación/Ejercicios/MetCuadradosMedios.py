#! /user/bin/python

num= int(raw_input("Ingrese el valor de la semilla"))
n= int(raw_input("Ingrese la cantidad de numeros aleatorios"))

for i in range (n):
    cuadrados= str (num*num)
    if (len(cuadrados)%2==1):
	    cuadrados="o"+cuadrados

    print "cuadrado:",cuadrados
	
    long1=len(cuadrados) -4
    long2=cuadrados(long1)//2.0
    
    num=int(cuadrados[long2:-long2])
    print num
