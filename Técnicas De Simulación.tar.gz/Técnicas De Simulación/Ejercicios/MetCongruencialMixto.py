#! /user/bin/python

x = int(raw_input("Introduce el valor de la semilla: "))
a = int(raw_input("Introduce el valor del multiplicador: "))
c = int(raw_input("Introduce el valor de la constante aditiva: "))
m = int(raw_input("Introduce el valor del modulo: "))

salida=[]

for i in range (0,m):
    
    x=(x * a + c) % m
    salida.append(x)
   
print salida
