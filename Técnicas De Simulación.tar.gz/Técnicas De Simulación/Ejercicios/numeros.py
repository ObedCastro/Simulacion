uni=['','uno','dos','tres','cuatro', 'cinco','seis','siete','ocho','nueve',]
dece=['','dieci','veinti','treinta','cuarenta','cincuenta','sesenta','setenta','novena','ochenta','noventa']
esp=['','diez']
def Bnum(num):
    
    

def fecha ():
	num= int(raw_input("ingrese el numero: "))
	
	print Bdia(dia)+ " de " +Bmes(mes)+" del 2016"
fecha()
