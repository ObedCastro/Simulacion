#!/usr/bin/env python
# -*- coding: utf-8 -*-

import wx
import wx.xrc
import os
import sys
import sqlite3
import sqliteclass
import ventana_hija
###########################################################################
## Clase Ventana Padre
###########################################################################

class MyFrame ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Registrar Empleado", pos = wx.DefaultPosition, size = wx.Size( 800,408 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )		
		fgSizer1 = wx.FlexGridSizer( 2, 2, 0, 0 )
		fgSizer1.SetFlexibleDirection( wx.BOTH )
		fgSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		fgSizer2 = wx.FlexGridSizer( 8, 3, 0, 0 )
		fgSizer2.SetFlexibleDirection( wx.BOTH )
		fgSizer2.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		self.m_staticText1 = wx.StaticText( self, wx.ID_ANY, u"ID", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )
		fgSizer2.Add( self.m_staticText1, 0, wx.ALL, 5 )
		self.txt_Id = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,-1 ), 0 )
		fgSizer2.Add( self.txt_Id, 0, wx.ALL, 5 )
		self.btn_Ver = wx.BitmapButton( self, wx.ID_ANY, wx.Bitmap( u"/home/luisjv/python/db/sqlite/imgs/search.png", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition,wx.Size( 50,30 ), wx.BU_AUTODRAW )
		fgSizer2.Add( self.btn_Ver, 0, wx.ALL, 5 )		
		self.m_staticText2 = wx.StaticText( self, wx.ID_ANY, u"DUI", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText2.Wrap( -1 )
		fgSizer2.Add( self.m_staticText2, 0, wx.ALL, 5 )
		self.txt_Dui = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 150,-1 ), 0 )
		fgSizer2.Add( self.txt_Dui, 0, wx.ALL, 5 )
		fgSizer2.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, u"NIT", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )
		fgSizer2.Add( self.m_staticText3, 0, wx.ALL, 5 )
		self.txt_Nit = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 150,-1 ), 0 )
		fgSizer2.Add( self.txt_Nit, 0, wx.ALL, 5 )
		fgSizer2.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		self.m_staticText4 = wx.StaticText( self, wx.ID_ANY, u"Nombre", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText4.Wrap( -1 )
		fgSizer2.Add( self.m_staticText4, 0, wx.ALL, 5 )
		self.txt_Nombre = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 200,-1 ), 0 )
		fgSizer2.Add( self.txt_Nombre, 0, wx.ALL, 5 )
		fgSizer2.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		self.m_staticText5 = wx.StaticText( self, wx.ID_ANY, u"Direccion", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText5.Wrap( -1 )
		fgSizer2.Add( self.m_staticText5, 0, wx.ALL, 5 )
		self.txt_Direccion = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 200,-1 ), 0 )
		fgSizer2.Add( self.txt_Direccion, 0, wx.ALL, 5 )
		fgSizer2.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		self.m_staticText6 = wx.StaticText( self, wx.ID_ANY, u"Salario", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText6.Wrap( -1 )
		fgSizer2.Add( self.m_staticText6, 0, wx.ALL, 5 )
		self.txt_Salario = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,-1 ), 0 )
		fgSizer2.Add( self.txt_Salario, 0, wx.ALL, 5 )
		fgSizer2.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		self.m_staticText7 = wx.StaticText( self, wx.ID_ANY, u"Edad", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText7.Wrap( -1 )
		fgSizer2.Add( self.m_staticText7, 0, wx.ALL, 5 )
		self.txt_Edad = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,-1 ), 0 )
		fgSizer2.Add( self.txt_Edad, 0, wx.ALL, 5 )
		fgSizer2.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )		
		self.m_staticText8 = wx.StaticText( self, wx.ID_ANY, u"Departamento", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText8.Wrap( -1 )
		fgSizer2.Add( self.m_staticText8, 0, wx.ALL, 5 )
		sel_DeptoChoices = []
		self.sel_Depto = wx.Choice( self, wx.ID_ANY, wx.DefaultPosition, wx.Size( 150,-1 ), sel_DeptoChoices, 0 )
		self.sel_Depto.SetSelection( 0 )
		fgSizer2.Add( self.sel_Depto, 0, wx.ALL, 5 )
		fgSizer1.Add( fgSizer2, 1, wx.EXPAND, 5 )
		gSizer2 = wx.FlexGridSizer( 2, 1, 0, 0 )
		gSizer2.AddSpacer( ( 0, 20), 1, wx.EXPAND, 5 )
		self.Imagen_bit = wx.StaticBitmap( self, wx.ID_ANY, wx.NullBitmap, wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer2.Add( self.Imagen_bit, 0, wx.ALL, 5 )
		fgSizer1.Add( gSizer2, 1, wx.EXPAND, 5 )
		gSizer1 = wx.FlexGridSizer( 1,5, 0, 0 )
		self.btn_Guardar = wx.Button( self, wx.ID_ANY, u"Guardar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_Guardar, 0, wx.ALL, 5 )
		self.btn_Update = wx.Button( self, wx.ID_ANY, u"Actualizar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_Update, 0, wx.ALL, 5 )
		self.btn_buscar_img = wx.Button( self, wx.ID_ANY, u"Buscar Img", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_buscar_img, 0, wx.ALL, 5 )
		self.btn_Eliminar = wx.Button( self, wx.ID_ANY, u"Eliminar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_Eliminar, 0, wx.ALL, 5 )
		self.btn_Salir = wx.Button( self, wx.ID_ANY, u"Salir", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_Salir, 0, wx.ALL, 5 )
		fgSizer1.Add( gSizer1, 1, wx.EXPAND, 5 )
		
		self.SetSizer( fgSizer1 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.txt_Id.Bind( wx.EVT_TEXT, self.BuscarDato )
	 	self.sel_Depto.Bind( wx.EVT_CHOICE, self.Seleccionar )
		self.btn_Guardar.Bind( wx.EVT_BUTTON, self.Guardar )
		self.btn_Salir.Bind( wx.EVT_BUTTON, self.Salir )
		self.btn_Update.Bind( wx.EVT_BUTTON, self.Actualizar )
		self.btn_Eliminar.Bind( wx.EVT_BUTTON, self.Eliminar )
		self.btn_buscar_img.Bind( wx.EVT_BUTTON, self.BuscarImg )
		self.btn_Ver.Bind( wx.EVT_BUTTON, self.Ver )
		#Clase para conexion
		self.db = sqliteclass.Database("datos_empleados.db")
		self.ruta = ""
		self.Cargar()
		#Maximo tamaño de imagen
		self.PhotoMaxSize=300
		#Imagen precarga por defecto
		self.ruta="guardar.png"
		self.frm_child = ""
		#Mensajes
		self.dial = wx.MessageDialog(None, 'DATOS GUARDADOS', 'Info', wx.OK|wx.CENTRE)
		self.dial_elimina = wx.MessageDialog(None, 'DATOS ELIMINADOS', 'Info', wx.OK|wx.CENTRE)
	def __del__( self ):
		pass
	def Ver( self, event ):
		self.frm_child = ventana_hija.Busqueda(self)
		self.frm_child.Show()
		self.btn_Ver.Enable(False)
	def Cargar(self):
		self.sel_Depto.Clear() # quita los renglones del objeto choice (select)
		sql="""select * from departamento """
		data_param=""
		typesql='S'
		self.rows=self.db.query(sql,data_param,typesql)		
		self.sel_Depto.Clear()	# Limpiar el combo antes de rellenar
		#Para rellenar el combo con los datos traidos de la bd.		
		for row in self.rows:		
		 	self.sel_Depto.Append(str(row[0])+"-"+row[1])	
	
	# Virtual event handlers, overide them in your derived class
	def Seleccionar( self, event ):
		event.Skip()

	def BuscarImg( self, event ):
		""" Buscar imagen en disco con un dialogo para  imagenes"""
		wildcard ="pictures (*.jpg,*.jpeg,*.png)|*.jpg;*.jpeg;*.png"
		self.dialog = wx.FileDialog(None, "Seleccione un archivo",wildcard=wildcard,style=wx.OPEN)
		
		if self.dialog.ShowModal() == wx.ID_OK:
			self.ruta=self.dialog.GetPath()
		self.dialog.Destroy() 
		self.VerImagen(self.ruta)
	
	def Guardar( self, event ):
		#db = sqliteclass.Database() #Instanciar la conexion a la Bd.
		sql="""select max(id) from empleado """
		data_param=''
		typesql='S'
		self.rows2=self.db.query(sql,data_param,typesql)	
		for row in self.rows2:
				nextid=row[0]+1
				idemp=(str(nextid))
		#Paso a variables los valores de los textbox
		direccion=self.txt_Direccion.GetValue()
		nombre=self.txt_Nombre.GetValue()
		salario=str(self.txt_Salario.GetValue())
		dui=str(self.txt_Dui.GetValue())
		nit=str(self.txt_Nit.GetValue())
		edad=str(self.txt_Edad.GetValue())
		departamento=self.sel_Depto.GetString(self.sel_Depto.GetSelection())
		depto=departamento.split('-')
		id_depto=depto[0]
		imagen = open(self.ruta,'r').read()
		binario = sqlite3.Binary(imagen)
		sql='INSERT INTO empleado(id,dui,nombre,edad,direccion,nit,salario,id_depto,imagen) VALUES (?,?,?,?,?,?,?,?,?)'
		data_param=(idemp,dui,nombre,edad,direccion,nit,salario,id_depto,binario)
		typesql='I'
		self.db.query(sql,data_param,typesql)
		self.dial.ShowModal()
	
	def BuscarDato( self, event ):
		#print "Buscar al dar Enter a la caja de texto"
		self.Buscar()

	def Salir( self, event ):
                exit()

	def Actualizar( self, event ):
		#print "Este boton es para actualizar"
		data_param=str(self.txt_Id.GetValue())
		typesql='U'
		ID = self.txt_Id.GetValue()
		Dui = self.txt_Dui.GetValue()
		Nombre =self.txt_Nombre.GetValue()
		Edad = self.txt_Edad.GetValue()
		Direccion = self.txt_Direccion.GetValue()
		Nit = self.txt_Nit.GetValue()
		Salario = self.txt_Salario.GetValue()
		imagen = open(self.ruta,'r').read()        
		binario = sqlite3.Binary(imagen)
		departamento=self.sel_Depto.GetString(self.sel_Depto.GetSelection())
		depto=departamento.split('-')
		id_depto=depto[0]
		data_param={'idR':ID,'DUI':Dui,'NOMBRE':Nombre,'EDAD':Edad,'DIRECCION':Direccion,'NIT':Nit,'SALARIO':Salario,'ID_DEPTO':id_depto,'IMAGEN':binario}
		sql="""UPDATE empleado SET dui=:DUI,nombre=:NOMBRE,edad=:EDAD,direccion=:DIRECCION,nit=:NIT,salario=:SALARIO,id_depto=:ID_DEPTO,imagen=:IMAGEN where id=:idR"""
		self.db.query(sql,data_param,typesql)
		self.dial.ShowModal()
                

	def Buscar( self ):
		cadena_buscar=self.txt_Id.GetValue()	
		if cadena_buscar!="":
			numreg=0
			typesql='S'
			data1=str(cadena_buscar)
			data_param= {'id1':data1} 
			sql="""SELECT count(*) FROM empleado  where id=:id1"""
			self.filas=self.db.query(sql,data_param,typesql)	
			for fila in self.filas:
				numreg=fila[0]
			if numreg>0:       
				sql="""select * from empleado where id=:id1"""
				self.rows=self.db.query(sql,data_param,typesql)	
		
				for row in self.rows:					           
					self.txt_Dui.SetValue(str(row[1]))
					self.txt_Nombre.SetValue(str(row[2]))
					self.txt_Edad.SetValue(str(row[3]))
					self.txt_Direccion.SetValue(str(row[4]))
					self.txt_Nit.SetValue(str(row[5]))
					self.txt_Salario.SetValue(str(row[6]))

					if row[8] is None: #row[8] es la posicion del cursor del campo imagen
						self.ruta='imgs/blank_img.png'
					else:			
						fout = open('newimg.jpg','wb') # Crear archivo para escribir imagen
						fout.write(str(row[8]))  #Escribir imagen desde Bd a otro Archivo en disco
						fout.close()
						self.ruta='newimg.jpg' 	
			else:
				self.txt_Dui.SetValue("")
				self.txt_Nombre.SetValue("")
				self.txt_Edad.SetValue("")
				self.txt_Direccion.SetValue("")
				self.txt_Nit.SetValue("")
				self.txt_Salario.SetValue("")
				
				self.ruta='imgs/blank_img.png'		
			self.VerImagen(self.ruta) #Llamar al metodo para ver la imagen
		 
	def VerImagen(self,path):
		"""Cargar y desplegar la imagen"""
		if path=='':
			self.ruta = self.txt_Ruta.GetValue()
		else:
			self.ruta=path
		#print self.ruta
		img = wx.Image(self.ruta, wx.BITMAP_TYPE_ANY)
		#Escala la imagen preservando la relacion de aspecto, es decir no deformarla visualmente
		W = img.GetWidth()
		H = img.GetHeight()
		
		if W > H:
			NewW = self.PhotoMaxSize
			NewH = self.PhotoMaxSize * H / W
		else:
			NewH = self.PhotoMaxSize
			NewW = self.PhotoMaxSize * W / H
		img = img.Scale(NewW,NewH)
		self.Imagen_bit.SetBitmap(wx.BitmapFromImage(img))
		self.Refresh()

	def Eliminar( self, event ):
		cadena_buscar=self.txt_Id.GetValue()	
		if cadena_buscar!="":
			data1=str(cadena_buscar)
			data_param= {'id1':data1}    
			sql="""delete from empleado  where id=:id1"""       
			typesql='D'
			self.rows=self.db.query(sql,data_param,typesql)	
		self.txt_Id.SetValue("")
		self.txt_Dui.SetValue("")
		self.txt_Nombre.SetValue("")
		self.txt_Edad.SetValue("")
		self.txt_Direccion.SetValue("")
		self.txt_Nit.SetValue("")
		self.txt_Salario.SetValue("")
		self.dial_elimina.ShowModal()
# end of class MyFrame
	
				       

class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame(None)
        self.SetTopWindow(frame)
        frame.Show()
        return 1
# end of class MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()
