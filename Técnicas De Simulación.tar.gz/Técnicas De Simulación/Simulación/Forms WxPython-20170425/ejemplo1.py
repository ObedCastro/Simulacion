# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr 18 2017)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Uso de Combobox, Choice y ListBox", pos = wx.DefaultPosition, size = wx.Size( 350,350 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		fgSizer1 = wx.FlexGridSizer( 7, 3, 0, 0 )
		fgSizer1.SetFlexibleDirection( wx.BOTH )
		fgSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer1.AddSpacer( ( 25, 25), 1, wx.EXPAND, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer1.AddSpacer( ( 25, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText1 = wx.StaticText( self, wx.ID_ANY, u"Seleccion ComboBox:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )
		fgSizer1.Add( self.m_staticText1, 0, wx.ALL, 5 )
		
		comboBox1Choices = [ u"C++", u"Python", u"PHP", u"Lua" ]
		self.comboBox1 = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,-1 ), comboBox1Choices, 0 )
		fgSizer1.Add( self.comboBox1, 0, wx.ALL, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText4 = wx.StaticText( self, wx.ID_ANY, u"Selecion Choice", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText4.Wrap( -1 )
		fgSizer1.Add( self.m_staticText4, 0, wx.ALL, 5 )
		
		choice1Choices = [ u"C++", u"Python", u"PHP", u"Lua", wx.EmptyString ]
		self.choice1 = wx.Choice( self, wx.ID_ANY, wx.DefaultPosition, wx.Size( 100,-1 ), choice1Choices, 0 )
		self.choice1.SetSelection( 0 )
		fgSizer1.Add( self.choice1, 0, wx.ALL, 5 )
		
		
		fgSizer1.AddSpacer( ( 25, 0), 1, wx.EXPAND, 5 )
		
		self.listbox1 = wx.StaticText( self, wx.ID_ANY, u"Seleccion Listbox", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.listbox1.Wrap( -1 )
		fgSizer1.Add( self.listbox1, 0, wx.ALL, 5 )
		
		listBox1Choices = [ u"C++", u"Python", u"PHP", u"Lua", wx.EmptyString ]
		self.listBox1 = wx.ListBox( self, wx.ID_ANY, wx.DefaultPosition, wx.Size( 100,50 ), listBox1Choices, 0 )
		fgSizer1.Add( self.listBox1, 0, wx.ALL, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.lblResultado = wx.StaticText( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.lblResultado.Wrap( -1 )
		fgSizer1.Add( self.lblResultado, 0, wx.ALL, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.lblResultado2 = wx.StaticText( self, wx.ID_ANY, u"     ", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.lblResultado2.Wrap( -1 )
		fgSizer1.Add( self.lblResultado2, 0, wx.ALL, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.lblResultado3 = wx.StaticText( self, wx.ID_ANY, u"     ", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.lblResultado3.Wrap( -1 )
		fgSizer1.Add( self.lblResultado3, 0, wx.ALL, 5 )
		
		
		self.SetSizer( fgSizer1 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.comboBox1.Bind( wx.EVT_COMBOBOX, self.SelectCombo )
		self.choice1.Bind( wx.EVT_CHOICE, self.SelectChoice )
		self.listBox1.Bind( wx.EVT_LISTBOX, self.SelectListbox )
	
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	def SelectCombo( self, event ):
		event.Skip()
	
	def SelectChoice( self, event ):
		event.Skip()
	
	def SelectListbox( self, event ):
		event.Skip()
	

