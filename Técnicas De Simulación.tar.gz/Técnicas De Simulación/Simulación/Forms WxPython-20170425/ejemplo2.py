# -*- coding: utf-8 -*- 

#importing wx files
import wx
 
#import  el  archivo GUI  con el codigo creado
import ejemplo1
 
#hereda de la clase MyFrame1 creada en wxFowmBuilder y crea la clase Form2
class Form2(ejemplo1.MyFrame1):
    #constructor
    def __init__(self,parent):
		#inicializa la clase superior(parent)
		ejemplo1.MyFrame1.__init__(self,parent)

    def SelectCombo( self, event ):
		self.lblResultado.SetLabel("Lenguaje Seleccionado: "+self.comboBox1.GetValue()+" desde Combobox") 
		# GetEventObject(): Retorna el objeto (usualmente una ventana) asociada con el evento, si hay algun objeto.
		# GetStringSelection():Retorna la etiqueta(string) del item  seleccionado un string vacio si no hay item seleccionado 
		selstring0 = event.GetEventObject().GetStringSelection()
		selstring1 =self.comboBox1.GetString(self.comboBox1.GetSelection())
		print selstring0
		print selstring1
    
    def SelectChoice( self, event ):
		#GetSelections() se usa para obtener el id del elemento seleccionado y GetString extrae el texto del id seleccionado
		self.lblResultado2.SetLabel("Lenguaje Seleccionado: "+ self.choice1.GetString(self.choice1.GetSelection())+" desde Choice") 
		selstring1 = event.GetEventObject().GetStringSelection()
		
		print selstring1
    
    def SelectListbox( self, event ):
		self.lblResultado3.SetLabel( "Lenguaje Seleccionado: "+self.listBox1.GetString(self.listBox1.GetSelection())+" desde ListBox")
		selstring2 = event.GetEventObject().GetStringSelection()
		print selstring2
        
 
# Fin de la clase  Calc
class MyApp(wx.App):
    def OnInit(self):
        form1 = Form2(None)
        self.SetTopWindow(form1)
        form1.Show()
        return 1


# Fin de la clase MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()	


