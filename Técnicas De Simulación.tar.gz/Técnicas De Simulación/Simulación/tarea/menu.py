# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr  7 2017)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import agregar, modificar,ver
import sqliteclass
import sqlite3

###########################################################################
## Class MyFrame2
###########################################################################

class MyFrame2 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 500,300 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		bSizer3 = wx.BoxSizer( wx.VERTICAL )
		
		gSizer1 = wx.GridSizer( 1, 1, 0, 0 )
		
		self.lista = wx.ListCtrl( self, wx.ID_ANY, wx.Point( 10,10 ), wx.Size( 480,200 ), wx.LC_REPORT|wx.SUNKEN_BORDER )
		gSizer1.Add( self.lista, 0, wx.ALL, 5 )
		
		
		bSizer3.Add( gSizer1, 1, wx.EXPAND, 5 )
		
		gSizer2 = wx.GridSizer( 1, 5, 0, 0 )
		
		self.btnnuevo = wx.Button( self, wx.ID_ANY, u"Agregar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer2.Add( self.btnnuevo, 0, wx.ALL, 5 )
		
		self.btneditar = wx.Button( self, wx.ID_ANY, u"Modificar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer2.Add( self.btneditar, 0, wx.ALL, 5 )
		
		self.btnEliminar = wx.Button( self, wx.ID_ANY, u"Eliminar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer2.Add( self.btnEliminar, 0, wx.ALL, 5 )
		
		self.btnVer = wx.Button( self, wx.ID_ANY, u"Ver", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer2.Add( self.btnVer, 0, wx.ALL, 5 )
		
		self.btnsalir = wx.Button( self, wx.ID_ANY, u"Salir", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer2.Add( self.btnsalir, 0, wx.ALL, 5 )
		
		
		bSizer3.Add( gSizer2, 1, wx.EXPAND, 5 )
		
		
		self.SetSizer( bSizer3 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.lista.Bind( wx.EVT_LIST_ITEM_SELECTED, self.Slecionar )
		self.btnnuevo.Bind( wx.EVT_BUTTON, self.Agregar )
		self.btneditar.Bind( wx.EVT_BUTTON, self.Modificar )
		self.btnEliminar.Bind( wx.EVT_BUTTON, self.Eliminar )
		self.btnVer.Bind( wx.EVT_BUTTON, self.Ver )
		self.btnsalir.Bind( wx.EVT_BUTTON, self.Salir )
		#Conexion Bd
		self.db = sqliteclass.Database("datos_empleados.db") #Instanciar la conexion a la Bd.
		#Evento cargar datos de encabezado a la lista y se definen las columnas que lleva el control
		self.lista.InsertColumn(0, 'Id', width=90)
		self.lista.InsertColumn(1, 'Nombre', width=95)
		self.lista.InsertColumn(2, 'Edad', width=100)
		self.lista.InsertColumn(3, 'Nit', width=110)
		self.lista.InsertColumn(4, 'Dui', width=115)
		self.lista.InsertColumn(5, 'Direccion', width=130)
		self.lista.InsertColumn(6, 'Salario', width=90)
		self.cargar()
	
		
	
	def __del__( self ):
		pass
		
	
	# Virtual event handlers, overide them in your derived class
	
	def cargar(self):
		self.lista.DeleteAllItems() # quita los renglones de la lista
		sql="""select * from empleado1"""
		data_param=''
		typesql='S'
		self.rows=self.db.query(sql,data_param,typesql)	
		self.row_count = 0
		#al tener el cursor se van insertando las columnas
		for row in self.rows:
			self.lista.InsertStringItem(self.row_count, str(row[0])) #Para insertar el indice de la fila pero del control va en la posicion columna 0
			self.lista.SetStringItem(self.row_count,1, str(row[2])) #en la fila insertada columna 1, se inserta el valor que queremos
			self.lista.SetStringItem(self.row_count,2, str(row[3])) #en la fila insertada columna 2, se inserta el valor siguiente 
			self.lista.SetStringItem(self.row_count,3, str(row[5]))
			self.lista.SetStringItem(self.row_count,4, str(row[1]))
			self.lista.SetStringItem(self.row_count,5, str(row[4]))
			self.lista.SetStringItem(self.row_count,6, str(row[6]))
			if self.row_count % 2:
				self.lista.SetItemBackgroundColour(self.row_count, "red")
			else:
				self.lista.SetItemBackgroundColour(self.row_count, "pink")
			self.row_count += 1
	
	def Mensaje(self, msg, title, style):
		dlg = wx.MessageDialog(parent=None, message=msg,caption=title, style=style)
		dlg.ShowModal()
		dlg.Destroy()
	
	def Slecionar( self, event ):
		self.item ='' 
		self.item2 =''
		self.item3=''
		self.item4='' 
		self.item = self.lista.GetFocusedItem() #traer la posicion del indice
		self.item2 = self.lista.GetItemText(self.item)#traer el texto del primera columna segun la posicion del indice
		self.item3 = self.lista.GetItemText(self.item)#traer el texto del primera columna segun la posicion del indice

	def seleccionar(self):
		#Funcion comun  seleccionar el valor de la lista
		#Seleccion del treeview
		self.treeselect = self.view.get_selection()
	def Agregar( self, event ):
		self.agregar = agregar.MyFrame2(self)
		self.agregar.Show()
		self.Hide()
		
	def Modificar( self, event ):
		indice = 0
		item= []
		selecion = self.lista.GetFirstSelected()
		if selecion != -1:
			while True:
				items= self.lista.GetItemText(selecion, indice)
				item.append(items)
				indice = indice +1
				if indice == 7:
					break
		idi = item[0]
		nombre = item[1]
		edad = item[2]
		nit = item[3]
		dui = item[4]
		direc = item[5]
		sal = item[6]
		self.modificar = modificar.MyFrame3(self)
		self.modificar.Show()
		self.modificar.txtid.SetValue(idi)
		self.modificar.txtnombre.SetValue(nombre)
		self.modificar.txtedad.SetValue(edad)
		self.modificar.txtnit.SetValue(nit)
		self.modificar.txtdui.SetValue(dui)
		self.modificar.txtdireccion.SetValue(direc)
		self.modificar.txtsalario.SetValue(sal)
		self.Hide()
	
	def Eliminar( self, event ):
		indice = 0
		item= []
		selecion = self.lista.GetFirstSelected()
		if selecion != -1:
			while True:
				items= self.lista.GetItemText(selecion, indice)
				item.append(items)
				indice = indice +1
				if indice == 7:
					break
		idi = item[0]
		conexion = sqlite3.connect('datos_empleados.db')
		c=conexion.cursor()
		c.execute("DELETE FROM empleado1 WHERE id=?",(idi))
		conexion.commit()
		print "Registros eliminados con exito"
		self.Mensaje("Datos eliminados con exito","Información - Tutorial", wx.OK|wx.ICON_INFORMATION)
		self.cargar()
		self.lista.Refresh()
		

	
	def Ver( self, event ):
		self.ver = ver.MyFrame6(self)
		self.ver.Show()
		self.Hide()
	
	def Salir( self, event ):
		self.Close()

	
			
		


					

	
# Fin de la clase  Calc
class MyApp(wx.App):
    def OnInit(self):
        form1 = MyFrame2(None)
        self.SetTopWindow(form1)
        form1.Show()
        return 1

# Fin de la clase MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()
