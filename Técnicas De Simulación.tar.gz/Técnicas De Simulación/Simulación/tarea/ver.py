# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr 29 2017)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import sqliteclass
###########################################################################
## Class MyFrame2
###########################################################################

class MyFrame6 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Busqueda", pos = wx.DefaultPosition, size = wx.Size( 500,300 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		bSizer2 = wx.BoxSizer( wx.VERTICAL )
		
		gSizer3 = wx.GridSizer( 2, 3, 0, 0 )
		
		self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, u"Busqueda:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )
		gSizer3.Add( self.m_staticText3, 0, wx.ALL, 5 )
		
		self.txtbusquea = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer3.Add( self.txtbusquea, 0, wx.ALL, 5 )
		
		self.btnbuscar = wx.Button( self, wx.ID_ANY, u"Buscar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer3.Add( self.btnbuscar, 0, wx.ALL, 5 )
		
		self.lista = wx.ListCtrl( self, wx.ID_ANY, wx.Point( 10,10 ), wx.Size( 480,200 ), wx.LC_REPORT|wx.SUNKEN_BORDER )
		gSizer3.Add( self.lista, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( gSizer3, 1, wx.EXPAND, 5 )
		
		
		self.SetSizer( bSizer2 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.txtbusquea.Bind( wx.EVT_TEXT, self.buscar1 )
		self.btnbuscar.Bind( wx.EVT_BUTTON, self.busqueda )
		self.lista.Bind( wx.EVT_LIST_ITEM_SELECTED, self.selec )
		
		#Conexion Bd
		self.db = sqliteclass.Database("datos_empleados.db") #Instanciar la conexion a la Bd.
		#Evento cargar datos de encabezado a la lista y se definen las columnas que lleva el control
		self.lista.InsertColumn(0, 'Id', width=90)
		self.lista.InsertColumn(1, 'Nombre', width=95)
		self.lista.InsertColumn(2, 'Edad', width=100)
		self.lista.InsertColumn(3, 'Nit', width=110)
		self.lista.InsertColumn(4, 'Dui', width=115)
		self.lista.InsertColumn(5, 'Direccion', width=130)
		self.lista.InsertColumn(6, 'Salario', width=90)
		self.cargar()
	
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	def busqueda( self, event ):
		self.cargar()
	def buscar1( self, event ):
		self.cargar()
	def selec( self, event ):
		event.Skip()
	def cargar(self):
		#evento para cargar datos de la bd a la lista de 2 maneras todos si el ctrl texto esta vacio 
		#o dependiendo de la busqueda con like asi muestra los resultados
		self.lista.DeleteAllItems() # quita los renglones de la lista
		cadena_buscar=self.txtbusquea.GetValue()	
		if cadena_buscar!="":
			self.prod="%"+str(cadena_buscar)+"%"
			sql="select * from empleado1 where nombre like ?"
			data_param=self.prod
			typesql='SL'
			self.rows=self.db.query(sql,data_param,typesql)
		else:	
			sql="""select * from empleado1"""
			data_param=''
			typesql='S'
			self.rows=self.db.query(sql,data_param,typesql)	
		self.row_count = 0
		#al tener el cursor se van insertando las columnas
		for row in self.rows:
			self.lista.InsertStringItem(self.row_count, str(row[0])) #Para insertar el indice de la fila pero del control va en la posicion columna 0
			self.lista.SetStringItem(self.row_count,1, str(row[2])) #en la fila insertada columna 1, se inserta el valor que queremos
			self.lista.SetStringItem(self.row_count,2, str(row[3])) #en la fila insertada columna 2, se inserta el valor siguiente 
			self.lista.SetStringItem(self.row_count,3, str(row[5]))
			self.lista.SetStringItem(self.row_count,4, str(row[1]))
			self.lista.SetStringItem(self.row_count,5, str(row[4]))
			self.lista.SetStringItem(self.row_count,6, str(row[6]))
			if self.row_count % 2:
				self.lista.SetItemBackgroundColour(self.row_count, "cyan")
			else:
				self.lista.SetItemBackgroundColour(self.row_count, "yellow")
			self.row_count += 1

# Fin de la clase  Calc
class MyApp(wx.App):
    def OnInit(self):
        form1 = MyFrame6(None)
        self.SetTopWindow(form1)
        form1.Show()
        return 1
'''
# Fin de la clase MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()

'''
