#ifndef FILE_TO_C_ARRAY_H
#define FILE_TO_C_ARRAY_H

class FileToCArray
{
public:
	static wxString Generate( const wxString& sourcepath );
};

#endif // FILE_TO_C_ARRAY_H
