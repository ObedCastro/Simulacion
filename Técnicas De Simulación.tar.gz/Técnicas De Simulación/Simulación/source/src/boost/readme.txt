wxFormBuilder Boost Smart Pointer
---------------------------------

1. A subset of boost library (v.1.31.0)
	wxFormBuilder just uses smart pointers from boost (shared_ptr/weak_ptr). There is no
	modifications with original boost, I only remove files that it's not necessary for
	building.

	You don't have to build this library because there are only headers files.

	You can find the complete boost library on http://boost.org.
	
Enjoy,
  The wxFormBuilder Team
  http://wxformbuilder.org