This directory and the symlink it contains were created automatically by premake
to facilitate execution of wxFormBuilder prior to installation on Unix platforms.
On Unix, wxFormBuilder expects to be executed from a directory named "output",
which is next to a directory named "share". The "share" directory should have a
subdirectory named "wxformbuilder", which contains the configuration files.