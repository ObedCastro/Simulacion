#! /usr/bin/env python
from subprocess import Popen, PIPE, STDOUT

#comandos[] = {'hola'}
def val(t):
	cmd = t
	p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
	output = p.stdout.read()
	print output


t=raw_input("ingrese comando: ")
val(t)
