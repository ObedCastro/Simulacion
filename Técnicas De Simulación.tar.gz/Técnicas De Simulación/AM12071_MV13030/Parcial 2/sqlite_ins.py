#! /usr/bin/env python
# -*- coding: utf-8 -*-
import sqlite3

conexion = sqlite3.connect('datos_empleados.db')
print "Conexion a Base de datos establecida "
id1=1
dui='0087554589-2'
nombre="Antonio Ramos"
edad=31
direcc="San Miguel"
nit='1312-210591-101-3'
salario=1000.0
c=conexion.cursor()
#id_depto=0
c.execute("INSERT INTO empleado VALUES (?,?,?,?,?,?,?)",(id1,dui,nombre,edad,direcc,nit,salario))
conexion.commit()
print "Registros creados con exito"
conexion.close()


