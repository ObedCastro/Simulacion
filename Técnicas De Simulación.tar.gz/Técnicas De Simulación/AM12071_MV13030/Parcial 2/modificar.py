# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr 26 2016)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import sqlite3
import wx
import wx.xrc

import menu

###########################################################################
## Class MyFrame3
###########################################################################

class MyFrame3 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 500,400 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		fgSizer3 = wx.FlexGridSizer( 9, 3, 0, 0 )
		fgSizer3.SetFlexibleDirection( wx.BOTH )
		fgSizer3.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 30, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText15 = wx.StaticText( self, wx.ID_ANY, u"ID", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText15.Wrap( -1 )
		self.m_staticText15.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText15, 0, wx.ALL, 5 )
		
		self.txtid = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer3.Add( self.txtid, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText16 = wx.StaticText( self, wx.ID_ANY, u"DUI", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText16.Wrap( -1 )
		self.m_staticText16.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText16, 0, wx.ALL, 5 )
		
		self.txtdui = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer3.Add( self.txtdui, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText17 = wx.StaticText( self, wx.ID_ANY, u"Nombre", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText17.Wrap( -1 )
		self.m_staticText17.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText17, 0, wx.ALL, 5 )
		
		self.txtnombre = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer3.Add( self.txtnombre, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText18 = wx.StaticText( self, wx.ID_ANY, u"Edad", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText18.Wrap( -1 )
		self.m_staticText18.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText18, 0, wx.ALL, 5 )
		
		self.txtedad = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer3.Add( self.txtedad, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText19 = wx.StaticText( self, wx.ID_ANY, u"Direccion", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText19.Wrap( -1 )
		self.m_staticText19.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText19, 0, wx.ALL, 5 )
		
		self.txtdireccion = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer3.Add( self.txtdireccion, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText20 = wx.StaticText( self, wx.ID_ANY, u"NIT", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText20.Wrap( -1 )
		self.m_staticText20.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText20, 0, wx.ALL, 5 )
		
		self.txtnit = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer3.Add( self.txtnit, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText21 = wx.StaticText( self, wx.ID_ANY, u"Salario", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText21.Wrap( -1 )
		self.m_staticText21.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText21, 0, wx.ALL, 5 )
		
		self.txtsalario = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer3.Add( self.txtsalario, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.btnmodificar = wx.Button( self, wx.ID_ANY, u"Actualizar", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.btnmodificar.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.btnmodificar, 0, wx.ALL, 5 )
		
		
		self.SetSizer( fgSizer3 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.btnmodificar.Bind( wx.EVT_BUTTON, self.Actualizar )
	
	def __del__( self ):
		pass
	

	def Mensaje(self, msg, title, style):
		dlg = wx.MessageDialog(parent=None, message=msg,caption=title, style=style)
		dlg.ShowModal()
		dlg.Destroy()	

	
	# Virtual event handlers, overide them in your derived class
	def Actualizar( self, event ):
		id1 = self.txtid.GetValue()
		dui=self.txtdui.GetValue()
		nombre=self.txtnombre.GetValue()
		edad=self.txtedad.GetValue()
		direccion=self.txtdireccion.GetValue()
		nit=self.txtnit.GetValue()
		salario=self.txtsalario.GetValue()
		
		conexion = sqlite3.connect('datos_empleados.db')
		c=conexion.cursor()
		c.execute("UPDATE empleado1 SET dui=?,nombre=?,edad=?,direccion=?,nit=?,salario=? WHERE id=?",(dui,nombre,edad,direccion,nit,salario,id1))
		conexion.commit()
		print "Registros actualizados con exito"
		self.Mensaje("Datos actualizados con exito","Información - Tutorial", wx.OK|wx.ICON_INFORMATION)
		
		
		self.menu = menu.MyFrame2(self)
		
		self.menu.Show()
		conexion.close()
		self.Hide()
		event.Skip()
	

