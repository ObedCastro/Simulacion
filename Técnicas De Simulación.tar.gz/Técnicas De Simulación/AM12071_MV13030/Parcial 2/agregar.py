# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr 26 2016)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import sqlite3
import wx
import wx.xrc
import menu

###########################################################################
## Class MyFrame2
###########################################################################

class MyFrame2 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 500,400 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		fgSizer3 = wx.FlexGridSizer( 9, 3, 0, 0 )
		fgSizer3.SetFlexibleDirection( wx.BOTH )
		fgSizer3.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 30, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText8 = wx.StaticText( self, wx.ID_ANY, u"ID", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText8.Wrap( -1 )
		self.m_staticText8.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText8, 0, wx.ALL, 5 )
		
		self.txtid = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), 0 )
		fgSizer3.Add( self.txtid, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText9 = wx.StaticText( self, wx.ID_ANY, u"DUI", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText9.Wrap( -1 )
		self.m_staticText9.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText9, 0, wx.ALL, 5 )
		
		self.txtdui = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), 0 )
		fgSizer3.Add( self.txtdui, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText10 = wx.StaticText( self, wx.ID_ANY, u"Nombre", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText10.Wrap( -1 )
		self.m_staticText10.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText10, 0, wx.ALL, 5 )
		
		self.txtnombre = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), 0 )
		fgSizer3.Add( self.txtnombre, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText11 = wx.StaticText( self, wx.ID_ANY, u"Edad", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText11.Wrap( -1 )
		self.m_staticText11.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText11, 0, wx.ALL, 5 )
		
		self.txtedad = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), 0 )
		fgSizer3.Add( self.txtedad, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText12 = wx.StaticText( self, wx.ID_ANY, u"Direccion", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText12.Wrap( -1 )
		self.m_staticText12.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText12, 0, wx.ALL, 5 )
		
		self.txtdireccion = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), 0 )
		fgSizer3.Add( self.txtdireccion, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText13 = wx.StaticText( self, wx.ID_ANY, u"NIT", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText13.Wrap( -1 )
		self.m_staticText13.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText13, 0, wx.ALL, 5 )
		
		self.txtnit = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), 0 )
		fgSizer3.Add( self.txtnit, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText14 = wx.StaticText( self, wx.ID_ANY, u"Salario", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText14.Wrap( -1 )
		self.m_staticText14.SetFont( wx.Font( 11, 74, 93, 90, False, "Liberation Sans" ) )
		
		fgSizer3.Add( self.m_staticText14, 0, wx.ALL, 5 )
		
		self.txtsalario = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), 0 )
		fgSizer3.Add( self.txtsalario, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.btnagregar = wx.Button( self, wx.ID_ANY, u"Insertar", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer3.Add( self.btnagregar, 0, wx.ALL, 5 )
		
		
		self.SetSizer( fgSizer3 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.btnagregar.Bind( wx.EVT_BUTTON, self.Agregar )
	
	def __del__( self ):
		pass
	
	
	# creamos un cuadro de dialogo o mensaje personalizado
	def Mensaje(self, msg, title, style):
		dlg = wx.MessageDialog(parent=None, message=msg,caption=title, style=style)
		dlg.ShowModal()
		dlg.Destroy()
		
	# Virtual event handlers, overide them in your derived class
	def Agregar( self, event ):
		
		dui=self.txtdui.GetValue()
		nombre=self.txtnombre.GetValue()
		edad=self.txtedad.GetValue()
		direccion=self.txtdireccion.GetValue()
		nit=self.txtnit.GetValue()
		salario=self.txtsalario.GetValue()
		
		conexion = sqlite3.connect('datos_empleados.db')
		c=conexion.cursor()
		c.execute("INSERT INTO empleado1 VALUES (?,?,?,?,?,?,?)",(None,dui,nombre,edad,direccion,nit,salario))
		conexion.commit()
		print "Registros creados con exito"
		self.Mensaje("Datos guardados con exito","Información - Tutorial", wx.OK|wx.ICON_INFORMATION)
		self.menu = menu.MyFrame2(self)
		self.menu.Show()
		self.Hide()
		conexion.close()
	

# Fin de la clase  Calc
class MyApp(wx.App):
    def OnInit(self):
        form1 = MyFrame2(None)
        self.SetTopWindow(form1)
        form1.Show()
        return 1

# Fin de la clase MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()
	

	

###########################################################################
## Class MyFrame3
###########################################################################

class MyFrame3 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 500,400 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		fgSizer4 = wx.FlexGridSizer( 9, 3, 0, 0 )
		fgSizer4.SetFlexibleDirection( wx.BOTH )
		fgSizer4.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer4.AddSpacer( ( 30, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText17 = wx.StaticText( self, wx.ID_ANY, u"Id", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText17.Wrap( -1 )
		fgSizer4.Add( self.m_staticText17, 0, wx.ALL, 5 )
		
		self.txtid = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.txtid, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText18 = wx.StaticText( self, wx.ID_ANY, u"Dui", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText18.Wrap( -1 )
		fgSizer4.Add( self.m_staticText18, 0, wx.ALL, 5 )
		
		self.txtdui = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.txtdui, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText19 = wx.StaticText( self, wx.ID_ANY, u"Nombre", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText19.Wrap( -1 )
		fgSizer4.Add( self.m_staticText19, 0, wx.ALL, 5 )
		
		self.txtnombre = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.txtnombre, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText20 = wx.StaticText( self, wx.ID_ANY, u"Edad", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText20.Wrap( -1 )
		fgSizer4.Add( self.m_staticText20, 0, wx.ALL, 5 )
		
		self.txtedad = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.txtedad, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText21 = wx.StaticText( self, wx.ID_ANY, u"Direccion", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText21.Wrap( -1 )
		fgSizer4.Add( self.m_staticText21, 0, wx.ALL, 5 )
		
		self.txtdireccion = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.txtdireccion, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText22 = wx.StaticText( self, wx.ID_ANY, u"Nit", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText22.Wrap( -1 )
		fgSizer4.Add( self.m_staticText22, 0, wx.ALL, 5 )
		
		self.txtnit = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.txtnit, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText23 = wx.StaticText( self, wx.ID_ANY, u"Salario", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText23.Wrap( -1 )
		fgSizer4.Add( self.m_staticText23, 0, wx.ALL, 5 )
		
		self.txtsalario = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.txtsalario, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.btnmodificar = wx.Button( self, wx.ID_ANY, u"Modificar", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer4.Add( self.btnmodificar, 0, wx.ALL, 5 )
		
		
		self.SetSizer( fgSizer4 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.btnmodificar.Bind( wx.EVT_BUTTON, self.Modificar )
	
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	def Modificar( self, event ):
		event.Skip()
	

# creamos un cuadro de dialogo o mensaje personalizado
	def Mensaje(self, msg, title, style):
		dlg = wx.MessageDialog(parent=None, message=msg,caption=title, style=style)
		dlg.ShowModal()
		dlg.Destroy()
		
	# Virtual event handlers, overide them in your derived class
	def Agregar( self, event ):
		
		dui=self.txtdui.GetValue()
		nombre=self.txtnombre.GetValue()
		edad=self.txtedad.GetValue()
		direccion=self.txtdireccion.GetValue()
		nit=self.txtnit.GetValue()
		salario=self.txtsalario.GetValue()
		
		conexion = sqlite3.connect('datos_empleados.db')
		c=conexion.cursor()
		c.execute("INSERT INTO empleado1 VALUES (?,?,?,?,?,?,?)",(None,dui,nombre,edad,direccion,nit,salario))
		conexion.commit()
		print "Registros creados con exito"
		self.Mensaje("Datos guardados con exito","Información - Tutorial", wx.OK|wx.ICON_INFORMATION)
		self.menu = menu.MyFrame2(self)
		self.menu.Show()
		self.Hide()
		conexion.close()
	

# Fin de la clase  Calc
class MyApp(wx.App):
    def OnInit(self):
        form1 = MyFrame2(None)
        self.SetTopWindow(form1)
        form1.Show()
        return 1

# Fin de la clase MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()
	
