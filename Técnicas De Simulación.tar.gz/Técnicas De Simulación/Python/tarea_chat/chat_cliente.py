# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun  7 2016)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import socket
###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 550,500 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		bSizer2 = wx.BoxSizer( wx.VERTICAL )
		
		fgSizer2 = wx.FlexGridSizer( 0, 5, 0, 0 )
		fgSizer2.SetFlexibleDirection( wx.BOTH )
		fgSizer2.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, u"Direccion", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )
		fgSizer2.Add( self.m_staticText3, 0, wx.ALL, 5 )
		
		self.direccion = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 200,-1 ), 0 )
		fgSizer2.Add( self.direccion, 0, wx.ALL, 5 )
		
		self.Puerto = wx.StaticText( self, wx.ID_ANY, u"Puerto", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.Puerto.Wrap( -1 )
		fgSizer2.Add( self.Puerto, 0, wx.ALL, 5 )
		
		self.puerto = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.puerto, 0, wx.ALL, 5 )
		
		self.m_button3 = wx.Button( self, wx.ID_ANY, u"Conectar", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.m_button3, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( fgSizer2, 1, wx.EXPAND, 5 )
		
		fgSizer1 = wx.FlexGridSizer( 0, 2, 0, 0 )
		fgSizer1.SetFlexibleDirection( wx.BOTH )
		fgSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_textCtrl2 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 427,-1 ), 0 )
		fgSizer1.Add( self.m_textCtrl2, 0, wx.ALL, 5 )
		
		self.m_button4 = wx.Button( self, wx.ID_ANY, u"Enviar", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1.Add( self.m_button4, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( fgSizer1, 1, wx.EXPAND, 5 )
		
		bSizer3 = wx.BoxSizer( wx.VERTICAL )
		
		self.mensage = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 550,500 ), wx.TE_MULTILINE )
		bSizer3.Add( self.mensage, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( bSizer3, 1, wx.EXPAND, 5 )
		
		
		self.SetSizer( bSizer2 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.m_button3.Bind( wx.EVT_BUTTON, self.conectar )
		self.m_textCtrl2.Bind( wx.EVT_TEXT_ENTER, self.mensaje )
		self.m_button4.Bind( wx.EVT_BUTTON, self.enviar )
	
		self.port =8080
		self.puerto.SetValue(str(self.port))
		self.direccion.SetValue('localhost')
	def __del__( self ):
		self.client.shutdown(socket.SHUT_RDWR)
		self.client.close()	
		#pass
	
	
	# Virtual event handlers, overide them in your derived class
	def conectar( self, event ):
		self.ip=str(self.direccion.GetValue())
		self.port =int(self.puerto.GetValue())
		self.client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		self.client.connect((self.ip, self.port))	
		event.Skip()
	
	def mensaje( self, event ):
		event.Skip()
	
	def enviar( self, event ):
		self.port =int(self.puerto.GetValue())
		self.ip=str(self.direccion.GetValue())
		#self.client.close()	
		#self.client.connect((self.ip, self.port))
		#def sendSocketMessage(message):
		"""Send a message to a socket"""
		try:
			#port = random.randint(1025,36000)
			self.message=self.m_textCtrl2.GetValue()			
			if self.message=='salir':
				self.Close()
			else:
				self.client.send(self.message)
			
				self.m_textCtrl2.SetValue("")
				
		except Exception, msg:
			print msg	
		event.Skip()	
# end of class MyFrame
class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame1(None)
        self.SetTopWindow(frame)
        frame.Show()
        return 1

# end of class MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()
        
#if __name__ == "__main__":
    #sendSocketMessage("Python rocks!")
    
