from socket import *
from time import ctime
import random
import threading

#import serial

# definir el puerto por el cual se recibiran las peticiones
port=8080
#Definimos el host,Es mejor dejarlo en blanco para recibir conexiones externas si es nuestro caso
host = ''
#definimos una tupla con los datos del host y el puerto
addr = (host, port)
#definimos en la variable  la cantidad de bytes para recibir desde un cliente
bufsiz = 1024
readdr = ''
# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun  7 2016)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 500,300 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		bSizer2 = wx.BoxSizer( wx.VERTICAL )
		
		fgSizer1 = wx.FlexGridSizer( 0, 2, 0, 0 )
		fgSizer1.SetFlexibleDirection( wx.BOTH )
		fgSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		
		self.m_textCtrl2 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 350,-1 ), 0 )
		fgSizer1.Add( self.m_textCtrl2, 0, wx.ALL, 5 )
		
		self.Enviar = wx.Button( self, wx.ID_ANY, u"Enviar", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1.Add( self.Enviar, 0, wx.ALL, 5 )
		
		bSizer2.Add( fgSizer1, 1, wx.EXPAND, 5 )
		
		bSizer3 = wx.BoxSizer( wx.VERTICAL )
		
		self.mensage = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 500,400 ), wx.TE_MULTILINE )
		bSizer3.Add( self.mensage, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( bSizer3, 1, wx.EXPAND, 5 )
		
		
		self.SetSizer( bSizer2 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.Enviar.Bind( wx.EVT_BUTTON, self.enviar )
		self.m_textCtrl2.Bind( wx.EVT_TEXT_ENTER, self.mensaje )
		
		self.thread = threading.Thread(target=self.Server)
		self.thread.start()
	
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	
	
	def mensaje( self, event ):
		event.Skip()
		
	def Print(self, text):
	    wx.CallAfter(self.mensage.AppendText, text + "\n")

	def Server(self):
	    self.Print("Puerto: {}".format(port))
	    #instanciamos un objeto para trabajar con el socket
	    self.tcpServer = socket(AF_INET , SOCK_STREAM)
	    #Con el metodo bind le indicamos que puerto debe escuchar y de que servidor esperar conexiones
	    # addr es una tupla que definimos anteriormente con el host y puerto
	    self.tcpServer.bind(addr)
	    #Aceptamos conexiones entrantes con el metodo listen, y ademas aplicamos como parametro
		    #El numero de conexiones entrantes que vamos a aceptar
	    self.tcpServer.listen(5)
	    try:
		while True:
		    self.Print("Esperando la conexion...")
		    #Instanciamos un objeto sc (socket cliente) para recibir datos, al recibir datos este 
				    #devolvera tambien un objeto que representa una tupla con los datos de conexion: IP y puerto
		    tcpClient, caddr = self.tcpServer.accept()
		    self.readdr=caddr
		    self.Print("Conectado desde {}".format(caddr))

		    while True:
					    #Recibimos el mensaje, con el metodo recv recibimos datos 
					    # y como parametro  la cantidad de bytes para recibir 
			data = tcpClient.recv(bufsiz)
			if not data:
			    break
			tcpClient.send('[%s]\nData\n%s' % (ctime(), data))
			self.Print(data)
		    tcpClient.close()

	    except KeyboardInterrupt:
		tcpServer.close()
	def enviar( self, event ):
		"""Send a message to a socket"""
		self.client = socket(AF_INET,SOCK_STREAM)
		self.client.connect(addr)	
		try:
			#port = random.randint(1025,36000)
			self.message=self.m_textCtrl2.GetValue()			
			if self.message=='salir':
				self.Close()
			else:
				self.client.send(self.message)
			
				self.m_textCtrl2.SetValue("")
				
		except Exception, msg:
			print msg	
		event.Skip()	
	
# end of class MyFrame
class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame1(None)
        self.SetTopWindow(frame)
        frame.Show()
        return 1

# end of class MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()
        
#if __name__ == "__main__":
    #sendSocketMessage("Python rocks!")
    

