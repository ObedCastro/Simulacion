#/usr/bin/python

semilla = 0
n = int(raw_input ("ingrese cantidad de semilla: "))
numeroaleatorio = int(raw_input ("ingrese un numero entero: "))
for i in range(0,n):
	cuadrado = str (numeroaleatorio**2)
	largo = len(cuadrado)
	if(largo < 8):
		cuadrado = cuadrado.zfill(8)
	parte = float(cuadrado[2:6]) /10000
	numeroaleatorio = int(cuadrado[2:6])
	print(str(i)+"---"+str(cuadrado)+"---"+str(cuadrado[2:6])+"----"+str(parte))


