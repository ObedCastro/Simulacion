iteracion = int (raw_input("Digite numero de itraciones: "))
semilla1 = int (raw_input("Digite semilla 1: "))
semilla2 = int (raw_input("Digite semilla 2: "))

for i in range(1,iteracion+1):
    numx = semilla1*semilla2

    if(len(str(numx))%2!=0):
        numx = str(numx).zfill(len(str(numx)) +1)

    longitudx = len(str(numx))
    longitud1 = len(str(semilla1))

    if(len(str(semilla2))>12):
        longitud1 = len(str(semilla2))

    nlongitud = longitudx-longitud1
    nlongitud = nlongitud / 2
    corte =str(numx)[nlongitud:(longitudx-nlongitud)]
    
    ndecimal = float(corte) / pow(10, longitud1)

    print(str(i)+"  "+str(semilla1)+"  "+str(semilla2)+"  "+str(numx)+"  "+str(corte)+"  "+str(ndecimal))

    semilla1=semilla2
    semilla2=int(corte)
