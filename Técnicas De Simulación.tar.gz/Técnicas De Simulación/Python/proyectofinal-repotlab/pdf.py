from reportlab.pdfgen import canvas

aux = canvas.Canvas("prueba1.pdf")

aux.drawImage("www.jpg",50,200,600,600)
aux.drawString(50,200,"EJEMPLO DE INSERCION DE IMAGEN EN PDF")

aux.showPage()
aux.save()
