#!/usr/bin/env python
# -*- coding: utf-8 -*- 

#basicos
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.units import cm
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib import pdfencrypt

c = canvas.Canvas("prueba1.pdf",pagesize=letter,bottomup=1)
c.setFont("Helvetica", 14)
#coordenadas por pixeles

c.drawString(100,100,"Medidas por Pixeles")
#coordenadas por pulgadas
c.drawString(inch, inch, "Medidas por Pulgadas")
#coordenadas por centimetros
c.drawString(5*cm,cm,'Medidas por centimetros')

#traslacion de posicion
c.translate(inch,2*inch)
c.line(1,1,100,1)#linea
c.translate(10*cm,cm)
c.grid([50,100,150], [-50,-100,-150])#cuadricula grid
c.circle(100, 20, 50, stroke=1, fill=0)#circulo sin relleno
c.circle(100, 20, 20, stroke=1, fill=1)#circulo con relleno
#imagen

c.drawImage('dory.jpg', -100,0, 100,100,0)

#texto
textobject = c.beginText()
textobject.setTextOrigin(-100,150)
textobject.setFont("Times-Roman", 14)
nu=0
for n in c.getAvailableFonts():
	c.setFont(n,14)
	c.drawString(-300,nu,n)
	nu=nu+20

textobject.setFillColorRGB(0,0,0)
textobject.textLines('''
Este es un texto escrito como tal, no un string aleatorio
''')
c.drawText(textobject)
c.setFont("Times-Roman", 14)

#colores
c.translate(-300,500)
black = colors.black
y = x = 0; dy=inch*3/4.0; dx=inch*5.5/5; w=h=dy/2; rdx=(dx-w)/2
rdy=h/5.0; texty=h+2*rdy
for [namedcolor, name] in (
		[colors.lavenderblush, "lavenderblush"],
		[colors.lawngreen, "lawngreen"],
		[colors.lemonchiffon, "lemonchiffon"],
		[colors.lightblue, "lightblue"],
	[colors.lightcoral, "lightcoral"]):
	c.setFillColor(namedcolor)
	c.rect(x+rdx, y+rdy, w, h, fill=1)
	c.setFillColor(black)
	c.drawCentredString(x+dx/2, y+texty, name)
	x = x+dx
y = y - dy; x = 0
for rgb in [(1,0,0), (0,1,0), (0,0,1), (0.5,0.3,0.1), (0.4,0.5,0.3)]:
	r,g,b = rgb
	c.setFillColorRGB(r,g,b)
	c.rect(x+rdx, y+rdy, w, h, fill=1)
	c.setFillColor(black)
	c.drawCentredString(x+dx/2, y+texty, "r%s g%s b%s"%rgb)
	x = x+dx
y = y - dy; x = 0
for gray in (0.0, 0.25, 0.50, 0.75, 1.0):
	c.setFillGray(gray)
	c.rect(x+rdx, y+rdy, w, h, fill=1)
	c.setFillColor(black)
	c.drawCentredString(x+dx/2, y+texty, "gray: %s"%gray)
	x = x+dx

c.showPage()
c.save()
