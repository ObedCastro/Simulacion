__version__='''$Id$'''
from reportlab.lib.testutils import setOutDir,makeSuiteForClasses, outputfile, printLocation
import unittest
from reportlab.platypus import Paragraph, SimpleDocTemplate, XBox, Indenter, XPreformatted, PageBreak ,Spacer, Table
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.abag import ABag
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER, TA_JUSTIFY
from reportlab.rl_config import defaultPageSize
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Image, Drawing
from reportlab.graphics import renderPDF
from reportlab.lib import pdfencrypt

import time

import sqliteclass
import sqlite3

db = sqliteclass.Database("base.sqlite")

(PAGE_WIDTH, PAGE_HEIGHT) = defaultPageSize

def myFirstPage(canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Bold',24)
    canvas.drawString(108, PAGE_HEIGHT-54, "Muestra de Reportlab con SQLITE")
    canvas.setFont('Times-Roman',12)
    canvas.drawString(4 * inch, 0.75 * inch, "Primera Pagina")
    canvas.restoreState()


def myLaterPages(canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Roman',12)
    canvas.drawString(4 * inch, 0.75 * inch, "Pagina %d" % doc.page)
    canvas.restoreState()


def test(id_emp):
    Fecha = time.strftime("%x")+'  '+time.strftime("%X")
    data_param=''
    sql="SELECT NAME,AGE,ADDRESS,SALARI,DUI,NIT,id_dpto,imagen,graficas FROM DATOS WHERE id="+id_emp
    row=db.query(sql,data_param,"S")
    for row1 in row:
	nombre=row1[0]
	edad=row1[1]
	direccion=row1[2]
	salario=row1[3]
	dui=row1[4]
	nit=row1[5]
	id_dpto=row1[6]
	sql="select * from departamento where id_dpto= "+str(id_dpto)
	data_param=""
	typesql='S'
	rows=db.query(sql,data_param,typesql)		
	for row2 in rows:		
	    departamento= row2[1]
	    print row2[1]
	imagen=row1[7]
	data=row1[8]
	if row1[7] is None: #row[7] es la posicion del cursor del campo imagen
	    ruta='img/blank_img.png'
	else:			
		fout = open('img/newimg.jpg','wb') # Crear archivo para escribir imagen
		fout.write(str(row1[7]))  #Escribir imagen desde Bd a otro Archivo en disco
		fout.close()
		ruta='img/newimg.jpg'
        
    
    
    noombre=nombre.split(' ')
    Nombre=noombre[0]
    
    story = []
    SA = story.append
    
    styNormal = ParagraphStyle('normal')
    styColor = ParagraphStyle('blue',parent=styNormal,textColor='blue')

    styDots = ParagraphStyle('styDots',parent=styNormal,endDots='.')
    styDots1 = ParagraphStyle('styDots1',parent=styNormal,endDots=ABag(text=' -',dy=2,textColor='red'))
    styDotsR = ParagraphStyle('styDotsR',parent=styNormal,alignment=TA_RIGHT)
    styDotsL = ParagraphStyle('styDotsL',parent=styNormal,alignment=TA_LEFT)
    styDotsC = ParagraphStyle('styDotsC',parent=styNormal,alignment=TA_CENTER)
    styDotsJ = ParagraphStyle('styDotsJ',parent=styNormal,alignment=TA_JUSTIFY)
    
    stySpaced = ParagraphStyle('spaced', parent=styNormal, spaceBefore=12, spaceAfter=12)
    
    SA(Spacer(1, 20))
    SA(Paragraph(Fecha, styDotsR))
    SA(Paragraph('<font size=14><b>Descripcion de Estado de Empleado</b></font>',styNormal))
    SA(Spacer(1, 40))
    d = Drawing(110, 44)
    inPath = ruta
    img = Image(0, -75, 110, 110, inPath)
    d.add(img)
    SA(d)
    SA(Spacer(1, 80))
    
    t = Table([
        ['Nombre: ', nombre], 
        ['Edad: ', str(edad)], 
        ['Direccion: ', direccion],
        ['Salario: ', str(salario)],
        ['DUI: ', str(dui)],
	['NIT: ', str(nit)],
	['Deparmatento: ', departamento]
    ], colWidths=200, rowHeights=20)
    
    t.setStyle([
        ('TEXTCOLOR', (0, 1), (1, -1), colors.black),
        #('TEXTCOLOR', (1, 0), (1, -1), colors.green),
        #('BACKGROUND',(1,1),(-1,-1),colors.purple),
        #('VALIGN', (0,0), (-1, -1), 'MIDDLE'),
    ])
    
    story.append(t)
    #SA(Spacer(1, 25))
    #SA(Paragraph('<font size=10><b>Nombre: </b></font>' +nombre, styNormal))
    #SA(Paragraph('<font size=10><b>Edad: </b></font>'+str(edad), styNormal))
    #SA(Paragraph('<font size=10><b>Direccion: </b></font>'+direccion, styNormal))
    #SA(Paragraph('<font size=10><b>Salario: </b></font> $'+str(salario), styNormal))
    #SA(Paragraph('<font size=10><b>DUI: </b></font>'+str(dui), styNormal))
    #SA(Paragraph('<font size=10><b>NIT: </b></font>'+str(nit), styNormal))
    #SA(Paragraph('<font size=10><b>Departamento: </b></font>'+departamento, styNormal))
    SA(Spacer(1, 30))
    SA(Paragraph('<font size=12><b>Porcentaje de Rendimiento Semestral</b></font>',styNormal))
    SA(Spacer(1, 40))
    drawing = Drawing(400, 200)

    bc = VerticalBarChart()
    bc.x = 50
    bc.y = 50
    bc.height = 175
    bc.width = 300
    datas=data.split(',')
    datoos=[]
    for datos in datas:
	lista = int(datos)
	datoos.append(lista)
    bc.data = [(datoos)]
    
    bc.strokeColor = colors.black

    bc.valueAxis.valueMin = 0
    bc.valueAxis.valueMax = 100
    bc.valueAxis.valueStep = 5

    bc.categoryAxis.labels.boxAnchor = 'c'
    #bc.categoryAxis.labels.dx = 8
    #bc.categoryAxis.labels.dy = -2
    #bc.categoryAxis.labels.angle = 30

    catNames = ['En', 'Feb', 'Mar', 'Abr', 'May', 'Jun']
    bc.categoryAxis.categoryNames = catNames
    drawing.add(bc)
    SA(drawing)
    
    #template = SimpleDocTemplate(outputfile('reportes/reporte_'+Nombre+'_.pdf'),showBoundary=0,encrypt=Nombre+'12345')
    template = SimpleDocTemplate(outputfile('reportes/reporte_'+Nombre+'_.pdf'),showBoundary=0)
    template.build(story,onFirstPage=myFirstPage, onLaterPages=myLaterPages)

