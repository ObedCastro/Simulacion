# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr 27 2016)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################
__version__='''$Id$'''
import os
import sys
import wx
import wx.xrc
import sqliteclass
import sqlite3
import unittest
from reportlab.lib.testutils import setOutDir,makeSuiteForClasses, outputfile, printLocation
import pdf_de_muestra 
setOutDir(__name__)
###########################################################################
## Class MyFrame2
###########################################################################

class MyFrame2 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Datos Empleado", pos = wx.DefaultPosition, size = wx.Size( 658,480 ), style =  wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )

		fgSizer3 = wx.FlexGridSizer( 0, 2, 0, 0 )
		bSizer1 = wx.BoxSizer( wx.VERTICAL )
		
		fgSizer2 = wx.FlexGridSizer( 0, 2, 0, 0 )
		fgSizer2.SetFlexibleDirection( wx.BOTH )
		fgSizer2.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, u"Id ", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )
		fgSizer2.Add( self.m_staticText3, 0, wx.ALL, 5 )
		
		self.txt_Id = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,28 ), 0 )
		fgSizer2.Add( self.txt_Id, 0, wx.ALL, 5 )
		
		self.m_staticText4 = wx.StaticText( self, wx.ID_ANY, u"DUI", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText4.Wrap( -1 )
		fgSizer2.Add( self.m_staticText4, 0, wx.ALL, 5 )
		
		self.txt_Dui = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,28 ), 0 )
		fgSizer2.Add( self.txt_Dui, 0, wx.ALL, 5 )
		
		self.m_staticText5 = wx.StaticText( self, wx.ID_ANY, u"NIT", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText5.Wrap( -1 )
		fgSizer2.Add( self.m_staticText5, 0, wx.ALL, 5 )
		
		self.txt_Nit = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,28 ), 0 )
		fgSizer2.Add( self.txt_Nit, 0, wx.ALL, 5 )
		
		self.m_staticText6 = wx.StaticText( self, wx.ID_ANY, u"Nombre", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText6.Wrap( -1 )
		fgSizer2.Add( self.m_staticText6, 0, wx.ALL, 5 )
		
		self.m_textCtrl7 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,28 ), 0 )
		fgSizer2.Add( self.m_textCtrl7, 0, wx.ALL, 5 )
		
		self.m_staticText7 = wx.StaticText( self, wx.ID_ANY, u"Direccion", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText7.Wrap( -1 )
		fgSizer2.Add( self.m_staticText7, 0, wx.ALL, 5 )
		
		self.m_textCtrl8 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,28 ), 0 )
		fgSizer2.Add( self.m_textCtrl8, 0, wx.ALL, 5 )
		
		self.m_staticText8 = wx.StaticText( self, wx.ID_ANY, u"Salario", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText8.Wrap( -1 )
		fgSizer2.Add( self.m_staticText8, 0, wx.ALL, 5 )
		
		self.m_textCtrl9 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 100,28 ), 0 )
		fgSizer2.Add( self.m_textCtrl9, 0, wx.ALL, 5 )
		
		self.m_staticText9 = wx.StaticText( self, wx.ID_ANY, u"Departamento", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText9.Wrap( -1 )
		fgSizer2.Add( self.m_staticText9, 0, wx.ALL, 5 )
		
		sel_DeptoChoices = []
		self.sel_Depto = wx.Choice( self, wx.ID_ANY, wx.DefaultPosition, wx.Size( 200,28 ), sel_DeptoChoices, 0 )
		self.sel_Depto.SetSelection( 0 )
		fgSizer2.Add( self.sel_Depto, 0, wx.ALL, 5 )
		
		self.m_staticText10 = wx.StaticText( self, wx.ID_ANY, u"Imagen", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText10.Wrap( -1 )
		fgSizer2.Add( self.m_staticText10, 0, wx.ALL, 5 )
		
		self.ruta_imagen = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,28 ), 0 )
		fgSizer2.Add( self.ruta_imagen, 0, wx.ALL, 5 )
		bSizer1.Add( fgSizer2, 1, wx.EXPAND, 5 )
		
		gSizer1 = wx.GridSizer( 0, 4, 0, 0 )
		
		self.btn_buscar = wx.Button( self, wx.ID_ANY, u"Buscar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_buscar, 0, wx.ALL, 5 )
		
		self.btn_actualizar = wx.Button( self, wx.ID_ANY, u"Actualizar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_actualizar, 0, wx.ALL, 5 )
		
		self.btn_Guardar = wx.Button( self, wx.ID_ANY, u"Guardar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_Guardar, 0, wx.ALL, 5 )
		
		self.m_staticText81 = wx.StaticText( self, wx.ID_ANY, u"Edad", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText81.Wrap( -1 )
		fgSizer2.Add( self.m_staticText81, 0, wx.ALL, 5 )
		
		self.m_textCtrl71 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.m_textCtrl71, 0, wx.ALL, 5 )
		
		self.m_button12 = wx.Button( self, wx.ID_ANY, u"Eliminar", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.m_button12, 0, wx.ALL, 5 )
		
		self.m_button13 = wx.Button( self, wx.ID_ANY, u"Imagen", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.m_button13, 0, wx.ALL, 5 )
		
		self.btn_Salir = wx.Button( self, wx.ID_ANY, u"Salir", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_Salir, 0, wx.ALL, 5 )
		
		self.btn_Reporte = wx.Button( self, wx.ID_ANY, u"Reporte", wx.DefaultPosition, wx.DefaultSize, 0 )
		gSizer1.Add( self.btn_Reporte, 0, wx.ALL, 5 )
				
		bSizer1.Add( gSizer1, 1, wx.EXPAND, 5 )
		fgSizer3.Add( bSizer1, 1, wx.EXPAND, 5 )
		
		self.img_Empleado = wx.StaticBitmap( self, wx.ID_ANY, wx.Bitmap( u"img/blank_img.png", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.Size( 150,175 ), 0 )
		fgSizer3.Add( self.img_Empleado, 0, wx.ALL, 5 )
		
		self.SetSizer( fgSizer3 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events 
		self.btn_Reporte.Bind( wx.EVT_BUTTON, self.Reporte )
		self.btn_buscar.Bind( wx.EVT_BUTTON, self.btn_buscarOnLeftClick )
		self.btn_actualizar.Bind( wx.EVT_BUTTON, self.btn_actualizarOnLeftClick )
		self.btn_Guardar.Bind( wx.EVT_BUTTON, self.Guardar )
		self.m_button12.Bind( wx.EVT_BUTTON, self.m_button12OnLeftClick )
		self.btn_Salir.Bind( wx.EVT_BUTTON, self.Salir )
		self.m_button13.Bind( wx.EVT_BUTTON, self.buscar_imagen )
		#Clase para conexion
		self.db = sqliteclass.Database("base.sqlite")
		self.PhotoMaxSize=200
		#Imagen precarga por defecto
		self.ruta="img/blank_img.png"
		self.Cargar()
		
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
		 	
	def VerImagen(self,path):
		"""Cargar y desplegar la imagen"""
		if path=='':
			self.ruta = self.ruta_imagen.GetValue()
		else:
			self.ruta=path
		#self.ruta="../imgs/blank_img.png"
		print self.ruta
		img = wx.Image(self.ruta, wx.BITMAP_TYPE_ANY)
		#Escala la imagen preservando la relacion de aspecto, es decir no deformarla visualmente
		W = img.GetWidth()
		H = img.GetHeight()
		
		if W > H:
			NewW = self.PhotoMaxSize
			NewH = self.PhotoMaxSize * H / W
		else:
			NewH = self.PhotoMaxSize
			NewW = self.PhotoMaxSize * W / H
		img = img.Scale(NewW,NewH)
		self.img_Empleado.SetBitmap(wx.BitmapFromImage(img))
		self.Refresh()
	
	def btn_buscarOnLeftClick( self, event ):
		id_emp=str(self.txt_Id.GetValue())
		data_param=''
		sql="SELECT NAME,AGE,ADDRESS,SALARI,DUI,NIT,id_dpto,imagen FROM DATOS WHERE id="+id_emp
		self.row2=self.db.query(sql,data_param,"S")	
		
		for row in self.row2:
			self.m_textCtrl7.SetValue(str(row[0]))
			self.m_textCtrl71.SetValue(str(row[1]))
			self.m_textCtrl8.SetValue(str(row[2]))
			self.m_textCtrl9.SetValue(str(row[3]))
			self.txt_Dui.SetValue(str(row[4]))
			self.txt_Nit.SetValue(str(row[5]))
			self.sel_Depto.SetStringSelection(str(row[6]))
			sql="""select * from departamento """
			data_param=""
			typesql='S'
			self.rows=self.db.query(sql,data_param,typesql)		
			#self.sel_Depto.Clear()	# Limpiar el combo antes de rellenar
			#Para rellenar el combo con los datos traidos de la bd.		
			for row1 in self.rows:		
				if row1[0] == row[6]:
					if row[6] is None:
						self.Cargar()					
					self.sel_Depto.SetStringSelection(str(row1[0])+'-'+str(row1[1]))
				else:
					self.sel_Depto.SetStringSelection("no tiene departamento")	
						
			if row[7] is None: #row[7] es la posicion del cursor del campo imagen
				self.ruta='img/blank_img.png'
			else:			
				fout = open('img/newimg.jpg','wb') # Crear archivo para escribir imagen
				fout.write(str(row[7]))  #Escribir imagen desde Bd a otro Archivo en disco
				fout.close()
				self.ruta='img/newimg.jpg' 	
			self.VerImagen(self.ruta) #Llamar al metodo para ver la imagen
			self.ruta_imagen.SetValue(str(self.ruta))
			event.Skip()
	
	def btn_actualizarOnLeftClick( self, event ):
		self.ruta=self.ruta_imagen.GetValue()
		imgdata = open(self.ruta, 'r').read() #Abrir archivo de imagen
		binario = sqlite3.Binary(imgdata)
		departamento=self.sel_Depto.GetString(self.sel_Depto.GetSelection())
		depto=departamento.split('-')
		id_depto=depto[0]
		prod_img={'duim':self.txt_Dui.GetValue(),'nombrem':self.m_textCtrl7.GetValue(),'edadm':self.m_textCtrl71.GetValue(),'direccionm':self.m_textCtrl8.GetValue(),'nitm':self.txt_Nit.GetValue(),'salariom':self.m_textCtrl9.GetValue(),'departamentom':id_depto,'idemp':self.txt_Id.GetValue(),'imgm':binario}
		sql=""" UPDATE DATOS SET DUI=:duim, NAME=:nombrem, AGE=:edadm, ADDRESS=:direccionm,
			NIT=:nitm, SALARI=:salariom, id_dpto=:departamentom, imagen=:imgm WHERE ID=:idemp """
		data_param=prod_img
		typesql='U'
		self.db.query(sql,data_param,typesql)	
		
		event.Skip()
	
	
	def Guardar( self, event ):
		db = sqliteclass.Database("base.sqlite") #Instanciar la conexion a la Bd.
		sql="""select max(id) from DATOS """
		data_param=''
		typesql='S'
		self.rows2=self.db.query(sql,data_param,typesql)	
		for row in self.rows2:
				nextid=row[0]+1
				idemp=(str(nextid))
		#Paso a variables los valores de los textbox
		direccion=self.m_textCtrl8.GetValue()
		nombre=self.m_textCtrl7.GetValue()
		salario=str(self.m_textCtrl9.GetValue())
		dui=str(self.txt_Dui.GetValue())
		nit=str(self.txt_Nit.GetValue())
		edad=str(self.m_textCtrl71.GetValue())
		departamento=self.sel_Depto.GetString(self.sel_Depto.GetSelection())
		depto=departamento.split('-')
		id_depto=depto[0]
		self.ruta=self.ruta_imagen.GetValue()
		imgdata = open(self.ruta, 'r').read() #Abrir archivo de imagen
		binario = sqlite3.Binary(imgdata)
		sql='INSERT INTO DATOS(ID,NAME,AGE,ADDRESS,SALARI,DUI,NIT,id_dpto,imagen) VALUES (?,?,?,?,?,?,?,?,?)'
		data_param=(idemp,nombre,edad,direccion,salario,dui,nit,id_depto,binario)
		typesql='I'
		self.db.query(sql,data_param,typesql)
		event.Skip()
	
	def m_button12OnLeftClick( self, event ):
		idemp = str(self.txt_Id.GetValue())
		sql="""DELETE  FROM DATOS WHERE id=?"""
		data_param=idemp
		typesql='D'
		#db=self.db
		self.rows=self.db.query(sql,data_param,typesql)	
		self.txt_Id.Clear()
		self.m_textCtrl7.Clear()
		self.m_textCtrl71.Clear()
		self.m_textCtrl8.Clear()
		self.m_textCtrl9.Clear()
		self.txt_Dui.Clear()
		self.txt_Nit.Clear()
		self.sel_Depto.Clear()
		event.Skip()
		
	
	def Salir( self, event ):
		self.Close()
		event.Skip()
	
	def buscar_imagen( self, event ):
		
		""" Buscar imagen en disco con un dialogo para  imagenes"""
		wildcard ="pictures (*.jpg,*.jpeg,*.png)|*.jpg;*.jpeg;*.png"
		self.dialog = wx.FileDialog(None, "Seleccione un archivo",wildcard=wildcard,style=wx.OPEN)
		
		if self.dialog.ShowModal() == wx.ID_OK:
			self.ruta=self.dialog.GetPath()
			self.ruta_imagen.SetValue(self.ruta)
		self.dialog.Destroy() 
		self.VerImagen(self.ruta)
		event.Skip()
		
	def Cargar(self):
		self.sel_Depto.Clear() # quita los renglones de la lista
		sql="""select * from departamento """
		data_param=""
		typesql='S'
		#db=self.db
		self.rows=self.db.query(sql,data_param,typesql)		
		self.sel_Depto.Clear()	# Limpiar el combo antes de rellenar
		#Para rellenar el combo con los datos traidos de la bd.		
		for row in self.rows:		
		 	self.sel_Depto.Append(str(row[0])+"-"+row[1])	
	
	def Reporte(self,event):
		idemp = str(self.txt_Id.GetValue())
		pdf_de_muestra.test(idemp)
		print "reporte generado"
		event.Skip()
		
		
class App(wx.App):
	def OnInit(self):
		self.frame = MyFrame2(None)
		self.frame.Show()
		return True


if __name__ == '__main__':
	app = App()
	app.MainLoop()
	printLocation()

