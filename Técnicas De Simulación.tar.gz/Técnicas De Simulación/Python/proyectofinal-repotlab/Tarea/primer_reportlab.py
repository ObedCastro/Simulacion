#!/usr/bin/env python
import time
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
 
doc = SimpleDocTemplate("carta de muestra.pdf",pagesize=letter,
                        rightMargin=72,leftMargin=72,
                        topMargin=72,bottomMargin=18)
sopa=[]
Fecha = time.ctime()
Nombre = "Juan Perez"
Direccion = ["Final 6ta calle oriente", "Col. El sacate, San Miguel"]

styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='Justify', alignment=TA_JUSTIFY))
ptext = '<font size=12>%s</font>' % Fecha
 
sopa.append(Paragraph(ptext, styles["Normal"]))
sopa.append(Spacer(1, 12))
 
# Create return address
ptext = '<font size=12>%s</font>' % Nombre
sopa.append(Paragraph(ptext, styles["Normal"]))       
for part in Direccion:
    ptext = '<font size=12>%s</font>' % part.strip()
    sopa.append(Paragraph(ptext, styles["Normal"]))   
 
sopa.append(Spacer(1, 12))
ptext = '<font size=12>Estimado %s: </font>' % Nombre.split()[0].strip()
sopa.append(Paragraph(ptext, styles["Normal"]))
sopa.append(Spacer(1, 12))
 
ptext = '<font size=12>Lorem ipsum dolor sit amet, consectetur adipiscing elit, \
		sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. \
		Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. \
		Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. \
		Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</font>'
sopa.append(Paragraph(ptext, styles["Justify"]))
sopa.append(Spacer(1, 12))
 
 
ptext = '<font size=12>Gracias por su comprencion.</font>'
sopa.append(Paragraph(ptext, styles["Justify"]))
sopa.append(Spacer(1, 12))
ptext = '<font size=12>Sinceramente,</font>'
sopa.append(Paragraph(ptext, styles["Normal"]))
sopa.append(Spacer(1, 48))
ptext = '<font size=12>Lorem Ipsum</font>'
sopa.append(Paragraph(ptext, styles["Normal"]))
sopa.append(Spacer(1, 12))
doc.build(sopa)
