from reportlab.pdfgen import canvas
from reportlab.lib.units import cm

c = canvas.Canvas("hoja.pdf")

c.drawString(9*cm, 22*cm, "Hello World")

c.showPage()
c.save()
