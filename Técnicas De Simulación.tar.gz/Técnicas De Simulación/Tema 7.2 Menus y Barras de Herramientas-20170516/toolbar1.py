#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Barra de Herramientas
'''

import wx

class Example(wx.Frame):
    
    def __init__(self, *args, **kwargs):
        super(Example, self).__init__(*args, **kwargs) 
            
        self.Design()
        
    def Design(self):  
        vbox = wx.BoxSizer(wx.VERTICAL)  
        toolbar1 = wx.ToolBar(self)
        newtool = toolbar1.AddLabelTool(wx.ID_ANY, 'Quit', wx.Bitmap('/home/luisjv/python/icons/page.png'))
        opentool = toolbar1.AddLabelTool(wx.ID_ANY, 'Quit', wx.Bitmap('/home/luisjv/python/icons/folder_page.png'))
        savetool = toolbar1.AddLabelTool(wx.ID_ANY, 'Quit', wx.Bitmap('/home/luisjv/python/icons/page_save.png'))
        qtool = toolbar1.AddLabelTool(wx.ID_ANY, 'Quit', wx.Bitmap('/home/luisjv/python/icons/cancel.png'))
        toolbar1.Realize()

        toolbar1.Realize()
        self.Bind(wx.EVT_TOOL, self.OnToolBar, newtool)
        self.Bind(wx.EVT_TOOL, self.OnToolBar, savetool)
        self.Bind(wx.EVT_TOOL, self.OnToolBar, opentool)
        self.Bind(wx.EVT_TOOL, self.OnQuit, qtool)
        vbox.Add(toolbar1, 0, wx.EXPAND)	
        self.SetSizer(vbox)
        self.SetSize((250, 200))
        self.SetTitle('Barra de Herramientas')
        self.Centre()
        self.Show(True)
        
    def OnQuit(self, e):
        self.Close()
    def OnToolBar(self, e):
		self.dial = wx.MessageDialog(None, 'PENDIENTE...', 'Info', wx.OK|wx.CENTRE)
		self.dial.ShowModal()
		self.dial.Close()
        

def main():
    
    ex = wx.App()
    Example(None)
    ex.MainLoop()    


if __name__ == '__main__':
    main()
