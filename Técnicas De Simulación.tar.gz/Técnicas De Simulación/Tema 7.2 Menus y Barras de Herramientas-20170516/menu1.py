# -*- coding: utf-8 -*- 
import wx
import wx.xrc
class MyFrame1 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 500,300 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		self.m_menubar2 = wx.MenuBar( 0 )
		self.menu1 = wx.Menu()
		self.submenu1 = wx.Menu()
		self.menuItem5 = wx.MenuItem( self.submenu1,wx.ID_NEW, u"&Nuevo", wx.EmptyString, wx.ITEM_NORMAL )
		self.submenu1.AppendItem( self.menuItem5 )
		
		self.menuItem6 = wx.MenuItem( self.submenu1, wx.ID_ANY, u"Item 2", wx.EmptyString, wx.ITEM_NORMAL )
		self.submenu1.AppendItem( self.menuItem6 )
		
		self.menu1.AppendSubMenu( self.submenu1, u"SubMenu 1" )
		
		self.menuItem1 = wx.MenuItem( self.menu1, wx.ID_ANY, u"Item 3", wx.EmptyString, wx.ITEM_NORMAL )
		self.menu1.AppendItem( self.menuItem1 )
		
		self.menuItem2 = wx.MenuItem( self.menu1, wx.ID_ANY, u"Item 4", wx.EmptyString, wx.ITEM_NORMAL )
		self.menu1.AppendItem( self.menuItem2 )
		
		self.m_menubar2.Append( self.menu1, u"Menu 1" ) 
		
		self.menu2 = wx.Menu()
		self.menuItem3 = wx.MenuItem( self.menu2, wx.ID_ANY, u"Item 1 Menu 2", wx.EmptyString, wx.ITEM_NORMAL )
		self.menu2.AppendItem( self.menuItem3 )
		
		self.menu2.AppendSeparator()
		
		self.menuItem4 = wx.MenuItem( self.menu2, wx.ID_ANY, u"Salir", wx.EmptyString, wx.ITEM_NORMAL )
		self.menuItem4.SetBitmap( wx.Bitmap( "/home/luisjv/python/wxpython/menus/exit.png", wx.BITMAP_TYPE_ANY ) )
		self.menu2.AppendItem( self.menuItem4 )

		
		self.m_menubar2.Append( self.menu2, u"Menu 2" ) 
		
		self.SetMenuBar( self.m_menubar2 )
		
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.Bind( wx.EVT_MENU, self.ItemSel3, id = self.menuItem1.GetId() )
		self.Bind( wx.EVT_MENU, self.ItemSel5, id = self.menuItem5.GetId() )
		self.Bind( wx.EVT_MENU, self.Salir, id = self.menuItem4.GetId() )
	
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	def ItemSel3( self, event ):
		print "Menu 1, Seleccionado Item 3"
	def ItemSel5( self, event ):
		print "Menu 1, Seleccionado Item Nuevo"
	
	def Salir( self, event ):
		exit()
	
class App(wx.App):
    def OnInit(self):
        frame =  MyFrame1(None)
        self.SetTopWindow(frame)
        frame.Show(True)
        return True

if __name__ == "__main__":
    app = App(0)
    app.MainLoop()		
	
