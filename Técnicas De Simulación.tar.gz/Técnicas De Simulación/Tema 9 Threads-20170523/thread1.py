#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function
import threading
import time


class MyThread(threading.Thread):
    def run(self):
        print("{} iniciado!".format(self.getName()))              # "Thread-x inicia!"
        time.sleep(1)                                      # retardo de un segundo
        print("{} finalizado!".format(self.getName()))             # "Thread-x finished!"

if __name__ == '__main__':
    for x in range(11):                                     # n veces ...
        mythread = MyThread(name = "Thread-{}".format(x + 1))  # ...Instancia el thread asignndo un id unico por cada thread
        mythread.start()                                   # ...inicia el thread
        time.sleep(0.9)      
