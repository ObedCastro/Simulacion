#!/usr/bin/python
# Nombre de Fichero : lote.py
import threading
from os import system
from time import sleep

class Trabajo(threading.Thread):
    """
    Esta es la clase Trabajo. Los Trabajos  se pueden ejecutar de 4 maneras
    Que esperen a estar solos para ejecutarse.
    Que esperen a estar solos para ejecutarse y no dejar ejecutar ningun otro hasta terminar.
    Que no dejen ejecutar a ninguno otro hasta terminar.
    Que se ejecuten sin restricciones mientras los otros lo dejen
    """
    def __init__(self, id, cmd, entroSolo = False ,salgoSolo = False):
        threading.Thread.__init__(self)
        self.cmd = cmd
        self.id = id
        self.entroSolo = entroSolo
        self.salgoSolo = salgoSolo

    def run(self):
        system(self.cmd)

print " ejecucion por lotes con thread"

trabajos = [Trabajo(1,"galculator",False,False),
           Trabajo(2,"gedit",False),
           Trabajo(3,"ls -la",False)]

for t in trabajos:
    while (t.entroSolo)  and (threading.activeCount() != 1):pass
    t.start()
    if (t.salgoSolo):
        t.join()
