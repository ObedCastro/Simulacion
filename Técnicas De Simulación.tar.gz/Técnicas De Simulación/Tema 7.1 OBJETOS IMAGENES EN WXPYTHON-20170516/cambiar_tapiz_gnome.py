# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr 18 2017)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
from subprocess import *
###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 500,500 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		bSizer1 = wx.BoxSizer( wx.HORIZONTAL )
		
		bSizer2 = wx.BoxSizer( wx.VERTICAL )
		
		self.img_Wallpaper = wx.StaticBitmap( self, wx.ID_ANY, wx.NullBitmap, wx.DefaultPosition, wx.Size( 400,400 ), 0 )
		bSizer2.Add( self.img_Wallpaper, 0, wx.ALL, 5 )
		
		
		bSizer1.Add( bSizer2, 1, wx.EXPAND, 5 )
		
		bSizer3 = wx.BoxSizer( wx.VERTICAL )
		
		
		bSizer3.AddSpacer( ( 0, 50), 1, wx.EXPAND, 5 )
		wildcard ="pictures (*.jpg,*.jpeg,*.png)|*.jpg;*.jpeg;*.png"
		self.m_filePicker1 = wx.FilePickerCtrl( self, wx.ID_ANY, wx.EmptyString, u"Seleccione un archivo:", wildcard , wx.DefaultPosition, wx.DefaultSize, wx.FLP_DEFAULT_STYLE )
		bSizer3.Add( self.m_filePicker1, 0, wx.ALL, 5 )
		
		self.cambiar = wx.Button( self, wx.ID_ANY, u"Cambiar", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.cambiar, 0, wx.ALL, 5 )
		
		self.btnSalir = wx.Button( self, wx.ID_ANY, u"Salir", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.btnSalir, 0, wx.ALL, 5 )
		
		
		bSizer1.Add( bSizer3, 1, wx.EXPAND, 5 )
		
		
		self.SetSizer( bSizer1 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.m_filePicker1.Bind( wx.EVT_FILEPICKER_CHANGED, self.BuscarImg )
		self.cambiar.Bind( wx.EVT_BUTTON, self.Cambiar )
		self.btnSalir.Bind( wx.EVT_BUTTON, self.Salir )
	

		#variables
		self.PhotoMaxSize=350
		self.ruta=""
		self.dial = wx.MessageDialog(None, 'CAMBIO REALIZADO', 'Info', wx.OK|wx.CENTRE)
	
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	def BuscarImg( self, event ):
		self.ruta=self.m_filePicker1.GetPath()
		print self.ruta
		self.VerImagen(self.ruta)

	def VerImagen(self,path):
		"""Cargar y desplegar la imagen"""
		self.ruta=path
		#self.ruta="../imgs/blank_img.png"
		print self.ruta
		img = wx.Image(self.ruta, wx.BITMAP_TYPE_ANY)
		#Escala la imagen preservando la relacion de aspecto, es decir no deformarla visualmente
		W = img.GetWidth()
		H = img.GetHeight()
		
		if W > H:
			NewW = self.PhotoMaxSize
			NewH = self.PhotoMaxSize * H / W
		else:
			NewH = self.PhotoMaxSize
			NewW = self.PhotoMaxSize * W / H
		img = img.Scale(NewW,NewH)
		self.img_Wallpaper.SetBitmap(wx.BitmapFromImage(img))
		self.Refresh()		
	def Cambiar( self, event ):
		imagen="'"+self.ruta+"'"
		string='/usr/bin/gsettings set org.gnome.desktop.background picture-uri file://%s'%imagen
		self.dial.ShowModal()
		call(string,shell=True)		
	def Salir( self, event ):
		self.Close()	
class App(wx.App):
    def OnInit(self):

        frame =  MyFrame1(None)
        self.SetTopWindow(frame)
        frame.Show(True)
        return True

if __name__ == "__main__":
    app = App(0)
    app.MainLoop()

	

