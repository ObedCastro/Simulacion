#!/usr/bin/env python
# -*- coding: utf-8 -*-
import wx
import wx.xrc
import sqlite3
import sqliteclass
###########################################################################
## Clase Ventana Hija
###########################################################################		
class Busqueda(wx.Frame):
	def __init__( self, parent ):
		self.title="Listar Empleados, Busqueda por Nombre"
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = self.title, pos = wx.DefaultPosition, size = wx.Size( 500,300 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )		
		fgSizer1 = wx.FlexGridSizer( 2, 1, 0, 0 )
		fgSizer1.SetFlexibleDirection( wx.BOTH )
		fgSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )		
		fgSizer2 = wx.FlexGridSizer( 0, 3, 0, 0 )
		fgSizer2.SetFlexibleDirection( wx.BOTH )
		fgSizer2.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )		
		self.m_staticText1 = wx.StaticText( self, wx.ID_ANY, u"Buscar", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )
		fgSizer2.Add( self.m_staticText1, 0, wx.ALL, 5 )		
		self.txt_Busqueda = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString,  wx.DefaultPosition, wx.Size( 250,-1 ), 0 )
		fgSizer2.Add(self.txt_Busqueda , 0, wx.ALL, 5 )		
		fgSizer1.Add( fgSizer2, 1, wx.EXPAND, 5 )		
		fgSizer3 = wx.FlexGridSizer( 1, 2, 0, 0 )
		fgSizer3.SetFlexibleDirection( wx.BOTH )
		fgSizer3.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		fgSizer3.AddSpacer( ( 30, 0), 1, wx.EXPAND, 5 )
		self.listctrl = wx.ListCtrl( self, wx.ID_ANY,  wx.Point( 10,10 ), wx.Size( 400,200 ), wx.LC_REPORT|wx.SUNKEN_BORDER )
		fgSizer3.Add( self.listctrl, 0, wx.ALL, 5 )
		fgSizer1.Add( fgSizer3, 1, wx.EXPAND, 5 )
		self.SetSizer( fgSizer1 )
		self.Layout()	
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.txt_Busqueda.Bind( wx.EVT_TEXT, self.Busqueda )
		self.listctrl.Bind(wx.EVT_LIST_ITEM_SELECTED, self.Seleccionar)
		#Conexion Bd
		self.db = sqliteclass.Database("datos_empleados.db") #Instanciar la conexion a la Bd.
		#Evento cargar datos de encabezado a la lista y se definen las columnas que lleva el control
		self.listctrl.InsertColumn(0, 'Id', width=100)
		self.listctrl.InsertColumn(1, 'Nombre', width=250)
		self.listctrl.InsertColumn(2, 'Edad', width=50)
		#Para referencia a la ventana padre
		self.padre = parent
		self.Cargar()
	
	def __del__( self ):
		#pass
		self.padre.btn_Ver.Enable(True)
	# Virtual event handlers, overide them in your derived class
	def Busqueda( self, event ):
		self.Cargar()	
	def Seleccionar(self, event):  
		self.item ='' 
		self.item2 ='' 
		self.item = self.listctrl.GetFocusedItem() #traer la posicion del indice
		self.item2 = self.listctrl.GetItemText(self.item)#traer el texto del primera columna segun la posicion del indice
		#llamar a la ventana padre el objeto txt_Id
		self.padre.txt_Id.SetValue('')
		self.padre.txt_Id.SetValue(self.item2)
		#Ejecutar metodo Buscar en la ventana padre 
		self.padre.Buscar()
	def Cargar(self):
		#evento para cargar datos de la bd a la lista de 2 maneras todos si el ctrl texto esta vacio 
		#o dependiendo de la busqueda con like asi muestra los resultados
		self.listctrl.DeleteAllItems() # quita los renglones de la lista
		cadena_buscar=self.txt_Busqueda.GetValue()	
		if cadena_buscar!="":
			self.prod="%"+str(cadena_buscar)+"%"
			sql="select * from empleado where nombre like ? order by id"
			data_param=self.prod
			typesql='SL'
			self.rows=self.db.query(sql,data_param,typesql)
		else:	
			sql="""select * from empleado order by id"""
			data_param=''
			typesql='S'
			self.rows=self.db.query(sql,data_param,typesql)	
		self.row_count = 0
		#al tener el cursor se van insertando las columnas
		for row in self.rows:
			self.listctrl.InsertStringItem(self.row_count, str(row[0])) #Para insertar el indice de la fila pero del control va en la posicion columna 0
			self.listctrl.SetStringItem(self.row_count,1, str(row[2])) #en la fila insertada columna 1, se inserta el valor que queremos
			self.listctrl.SetStringItem(self.row_count,2, str(row[3])) #en la fila insertada columna 2, se inserta el valor siguiente 			
			if self.row_count % 2:
				self.listctrl.SetItemBackgroundColour(self.row_count, "cyan")
			else:
				self.listctrl.SetItemBackgroundColour(self.row_count, "yellow")
			self.row_count += 1          
# end of class Busqueda
