#!/usr/bin/env python
#-*- coding: utf-8 -*-
""" Dado un numero entero positivo por medio de teclado, conviertalo a
# una cadena de texto que escriba su numero por ejemplo
# 236 = Doscientos treinta y seis
"""


import numtext2 as numtext
valorconvertir = int(raw_input("Ingrese un numero entero: "))

y = numtext.Numbers()
num2 = y.convert(valorconvertir)
print "Numero: ",str(valorconvertir), " Texto: " ,  num2

