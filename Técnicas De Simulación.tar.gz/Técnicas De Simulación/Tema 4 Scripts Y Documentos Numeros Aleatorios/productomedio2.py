#!/usr/bin/env python
# -*- coding: utf-8 -*-
import math
""" Método de Producto medio:
 este método es un poco similar al de cuadrados medios
pero se debe comenzar con dos semillas cada una con k dígitos, el número
resultante se toma como las cifras centrales del producto de los dos números
anteriores. Por ejemplo, tomando como semillas a X0 =13 y X1 =15 el método
sería el siguiente:
X 2 = (13*15)= 0195 = 19, luego R 2 =19 / 100 = 0.19.
X 3 = (15*19) = 0285 = 28, luego R 3 = 28 / 100 = 0.28.
X 4 = (19*28) = 0532 = 53, luego R 4 =53 / 100 = 0.53.
"""
n = int(raw_input("Introduce el numero de experimentos: "))
semilla0=  raw_input("Introduce el valor de la semilla 0: ")
semilla1=  raw_input("Introduce el valor de la semilla 1: ")
for i in range(n):
	x=int(semilla0)*int(semilla1)
	stringx=str(x)
	longcadena=len(stringx)
	cadena_espar=longcadena%2
	
	if cadena_espar!=0:
		stringx="0"+stringx
	longcadena=len(stringx)
	cortar=longcadena//2
	cortar_inicio=cortar//2
	cortar_fin=longcadena-cortar_inicio	
	print ('cortar',cortar,cortar_inicio,cortar_fin)

	semillanueva=stringx[cortar_inicio:cortar_fin]
	semilla0=semilla1
	semilla1=semillanueva
	dx=pow(10,len(semillanueva))	
	
	semilla3=(int(semillanueva)*1.0)/dx
	print (i, stringx, semillanueva, semilla3)
