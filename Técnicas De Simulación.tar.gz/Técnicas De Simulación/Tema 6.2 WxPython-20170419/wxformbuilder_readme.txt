1) aptitude install libwxgtk3.0-0 libwxgtk3.0-dev libwxgtk-media3.0-dev

2) aptitude install python-wxtools

3) ./create_build_files4.sh

4)cd build/3.0/gmake
5) make config=release


6) cd ../../../output/bin/
7) ./wxformbuilder
