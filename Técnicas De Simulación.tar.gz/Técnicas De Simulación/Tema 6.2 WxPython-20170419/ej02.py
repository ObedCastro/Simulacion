# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Apr 18 2017)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import string
########################################################################
class CharValidator(wx.PyValidator):
    ''' Validates data as it is entered into the text controls. '''

    #----------------------------------------------------------------------
    def __init__(self, flag):
        wx.PyValidator.__init__(self)
        self.flag = flag
        self.Bind(wx.EVT_CHAR, self.OnChar)

    #----------------------------------------------------------------------
    def Clone(self):
        '''Required Validator method'''
        return CharValidator(self.flag)

    #----------------------------------------------------------------------
    def Validate(self, win):
        return True

    #----------------------------------------------------------------------
    def TransferToWindow(self):
        return True

    #----------------------------------------------------------------------
    def TransferFromWindow(self):
        return True

    #----------------------------------------------------------------------
    def OnChar(self, event):
        keycode = int(event.GetKeyCode())
        if keycode < 256:
            #print keycode
            key = chr(keycode)
            #print key
            if self.flag == 'no-alpha' and key in string.letters:
                return
            if self.flag == 'no-digit' and key in string.digits:
                return
        event.Skip()

###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = "Operaciones Basicas 2 Num. y Validador", pos = wx.DefaultPosition, size = wx.Size( 460,220 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		
		bSizer2 = wx.BoxSizer( wx.VERTICAL )
		
		fgSizer3 = wx.FlexGridSizer( 4, 3, 0, 0 )
		fgSizer3.SetFlexibleDirection( wx.BOTH )
		fgSizer3.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		
		fgSizer3.AddSpacer( ( 0, 20), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer3.AddSpacer( ( 20, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText6 = wx.StaticText( self, wx.ID_ANY, u"Valor 1:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText6.Wrap( -1 )
		fgSizer3.Add( self.m_staticText6, 0, wx.ALL, 5 )
		
		self.txtVal1 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0,validator=CharValidator('no-alpha') )
		fgSizer3.Add( self.txtVal1, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText7 = wx.StaticText( self, wx.ID_ANY, u"Valor 2:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText7.Wrap( -1 )
		fgSizer3.Add( self.m_staticText7, 0, wx.ALL, 5 )
		
		self.txtVal2 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 ,validator=CharValidator('no-alpha') )
		fgSizer3.Add( self.txtVal2, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 5, 0), 1, wx.EXPAND, 5 )
		
		self.m_staticText9 = wx.StaticText( self, wx.ID_ANY, u"Resultado:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText9.Wrap( -1 )
		fgSizer3.Add( self.m_staticText9, 0, wx.ALL, 5 )
		
		self.txtRes = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 ,validator=CharValidator('no-alpha') )
		fgSizer3.Add( self.txtRes, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( fgSizer3, 1, wx.EXPAND, 5 )
		
		bSizer3 = wx.BoxSizer( wx.HORIZONTAL )
		
		
		bSizer3.AddSpacer( ( 15, 0), 1, wx.EXPAND, 5 )
		
		self.btnSumar = wx.Button( self, wx.ID_ANY, u"Sumar", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.btnSumar, 0, wx.ALL, 5 )
		
		self.btnRestar = wx.Button( self, wx.ID_ANY, u"Restar", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.btnRestar, 0, wx.ALL, 5 )
		
		self.btnMultiplicar = wx.Button( self, wx.ID_ANY, u"Multiplicar", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.btnMultiplicar, 0, wx.ALL, 5 )
		
		self.btnDividir = wx.Button( self, wx.ID_ANY, u"Dividir", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.btnDividir, 0, wx.ALL, 5 )
		
		self.btnLimpiar = wx.Button( self, wx.ID_ANY, u"Limpiar", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.btnLimpiar, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( bSizer3, 1, wx.EXPAND, 5 )
		
		
		self.SetSizer( bSizer2 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.btnSumar.Bind( wx.EVT_BUTTON, self.Sumar )
		self.btnRestar.Bind( wx.EVT_BUTTON, self.Restar )
		self.btnMultiplicar.Bind( wx.EVT_BUTTON, self.Multiplicar )
		self.btnDividir.Bind( wx.EVT_BUTTON, self.Dividir )
		self.btnLimpiar.Bind( wx.EVT_BUTTON, self.Limpiar )
	
	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	def Sumar( self, event ):
		self.a=float(self.txtVal1.GetValue()) 
		self.b=float(self.txtVal2.GetValue())
		self.resp=self.a+self.b
		self.txtRes.SetValue(str(self.resp))
			
	
	def Restar( self, event ):
		self.a=float(self.txtVal1.GetValue()) 
		self.b=float(self.txtVal2.GetValue())
		self.resp=self.a-self.b
		self.txtRes.SetValue(str(self.resp))
	
	def Multiplicar( self, event ):
		self.a=float(self.txtVal1.GetValue()) 
		self.b=float(self.txtVal2.GetValue())
		self.resp=self.a*self.b
		self.txtRes.SetValue(str(self.resp))
	
	def Dividir( self, event ):
		self.a=float(self.txtVal1.GetValue()) 
		self.b=float(self.txtVal2.GetValue())
		self.resp=self.a/self.b
		self.txtRes.SetValue(str(self.resp))
	
	def Limpiar( self, event ):
		self.txtVal1.SetValue("")
		self.txtVal2.SetValue("")
		self.txtRes.SetValue("")
		
# end of class MyFrame
class MyApp(wx.App):
    def OnInit(self):
        form1 = MyFrame1(None)
        self.SetTopWindow(form1)
        form1.Show()
        return 1

# end of class MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()	


